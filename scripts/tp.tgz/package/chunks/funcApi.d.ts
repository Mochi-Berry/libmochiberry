import { Temporal } from 'temporal-spec';
import * as TemporalUtils from 'temporal-utils';
import { DateFields, DayFields, DateTimeFields, MonthDayFields } from './internal.js';

type OverflowOptions = Temporal.OverflowOptions;
type RoundingMode = TemporalUtils.RoundingMode;
type RoundingMathOptions = TemporalUtils.RoundingMathOptions;
type DisambiguationOptions = Temporal.DisambiguationOptions;

declare const CalendarRecordBrand: unique symbol;
declare const PlainDateRecordBrand: unique symbol;
declare const PlainDateTimeRecordBrand: unique symbol;
declare const PlainTimeRecordBrand: unique symbol;
declare const PlainYearMonthRecordBrand: unique symbol;
declare const PlainMonthDayRecordBrand: unique symbol;
declare const InstantRecordBrand: unique symbol;
declare const ZonedDateTimeRecordBrand: unique symbol;
declare const DurationRecordBrand: unique symbol;
type CalendarRecord = {
    readonly [CalendarRecordBrand]: undefined;
    toJSON(): string;
    valueOf(): string;
};
type PlainDateRecord = {
    readonly [PlainDateRecordBrand]: undefined;
    readonly calendarId: string;
    readonly era: string | undefined;
    readonly eraYear: number | undefined;
    readonly year: number;
    readonly month: number;
    readonly monthCode: string;
    readonly day: number;
    toJSON(): string;
    valueOf(): never;
};
type PlainDateTimeRecord = {
    readonly [PlainDateTimeRecordBrand]: undefined;
    readonly calendarId: string;
    readonly era: string | undefined;
    readonly eraYear: number | undefined;
    readonly year: number;
    readonly month: number;
    readonly monthCode: string;
    readonly day: number;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
    readonly millisecond: number;
    readonly microsecond: number;
    readonly nanosecond: number;
    toJSON(): string;
    valueOf(): never;
};
type PlainTimeRecord = {
    readonly [PlainTimeRecordBrand]: undefined;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
    readonly millisecond: number;
    readonly microsecond: number;
    readonly nanosecond: number;
    toJSON(): string;
    valueOf(): never;
};
type PlainYearMonthRecord = {
    readonly [PlainYearMonthRecordBrand]: undefined;
    readonly calendarId: string;
    readonly era: string | undefined;
    readonly eraYear: number | undefined;
    readonly year: number;
    readonly month: number;
    readonly monthCode: string;
    toJSON(): string;
    valueOf(): never;
};
type PlainMonthDayRecord = {
    readonly [PlainMonthDayRecordBrand]: undefined;
    readonly calendarId: string;
    readonly monthCode: string;
    readonly day: number;
    toJSON(): string;
    valueOf(): never;
};
type InstantRecord = {
    readonly [InstantRecordBrand]: undefined;
    readonly epochMilliseconds: number;
    readonly epochNanoseconds: bigint;
    toJSON(): string;
    valueOf(): never;
};
type ZonedDateTimeRecord = {
    readonly [ZonedDateTimeRecordBrand]: undefined;
    readonly calendarId: string;
    readonly epochMilliseconds: number;
    readonly epochNanoseconds: bigint;
    readonly timeZoneId: string;
    readonly era: string | undefined;
    readonly eraYear: number | undefined;
    readonly year: number;
    readonly month: number;
    readonly monthCode: string;
    readonly day: number;
    readonly hour: number;
    readonly minute: number;
    readonly second: number;
    readonly millisecond: number;
    readonly microsecond: number;
    readonly nanosecond: number;
    toJSON(): string;
    valueOf(): never;
};
type DurationRecord = {
    readonly [DurationRecordBrand]: undefined;
    readonly years: number;
    readonly months: number;
    readonly weeks: number;
    readonly days: number;
    readonly hours: number;
    readonly minutes: number;
    readonly seconds: number;
    readonly milliseconds: number;
    readonly microseconds: number;
    readonly nanoseconds: number;
    toJSON(): string;
    valueOf(): never;
};

type DateTimeFormatLike<R> = Omit<Intl.DateTimeFormat, 'format' | 'formatToParts' | 'formatRange' | 'formatRangeToParts'> & {
    format(record: R): string;
    formatToParts(record: R): Intl.DateTimeFormatPart[];
    formatRange(record0: R, record1: R): string;
    formatRangeToParts(record0: R, record1: R): ReturnType<Intl.DateTimeFormat['formatRangeToParts']>;
};
type PlainDateToZonedDateTimeOptions<PlainTimeRecord> = {
    timeZone: string;
    plainTime?: PlainTimeRecord;
};
type RelativeToRecord<ZonedDateTimeRecord, PlainDateTimeRecord, PlainDateRecord> = ZonedDateTimeRecord | PlainDateTimeRecord | PlainDateRecord;
type DateFromFields<CalendarRecord> = Partial<DateFields> & DayFields & {
    calendar?: CalendarRecord;
};
type DateTimeFromFields<CalendarRecord> = Partial<DateTimeFields> & DayFields & {
    calendar?: CalendarRecord;
};
type MonthDayFromFields<CalendarRecord> = Partial<MonthDayFields> & DayFields & {
    calendar?: CalendarRecord;
};
type ZonedDateTimeFields<CalendarRecord> = Partial<DateTimeFields> & DayFields & {
    calendar?: CalendarRecord;
    offset?: string;
    timeZone: string;
};

export type { CalendarRecord, DateFromFields, DateTimeFormatLike, DateTimeFromFields, DisambiguationOptions, DurationRecord, InstantRecord, MonthDayFromFields, OverflowOptions, PlainDateRecord, PlainDateTimeRecord, PlainDateToZonedDateTimeOptions, PlainMonthDayRecord, PlainTimeRecord, PlainYearMonthRecord, RelativeToRecord, RoundingMathOptions, RoundingMode, ZonedDateTimeFields, ZonedDateTimeRecord };
