import { createPropDescriptors, createDateTimeFormatShell, memoize, throwTypeError, invalidFormatType, applyPlainFormatTimeZone, transformMonthDayOptions, transformYearMonthOptions, transformTimeOptions, transformDateOptions, transformDateTimeOptions, transformInstantOptions, RawDateTimeFormat, mismatchingFormatTypes, checkResolvedCalendarCompatible, timeFieldsToMilli, isoDateToEpochMilli, isoDateTimeToEpochMilli, epochNanoToMilli } from "./internal.js";

import { PlainMonthDayBranding, PlainYearMonthBranding, PlainTimeBranding, PlainDateBranding, PlainDateTimeBranding, InstantBranding } from "./apiHelpers.js";

function createIntlExtended(DateTimeFormat) {
  return Object.defineProperties(Object.create(Intl), createPropDescriptors({
    DateTimeFormat: DateTimeFormat
  }));
}

function createDateTimeFormatClass(getTemporalBrandingAndSlots) {
  return createDateTimeFormatShell(internals => {
    const getTemporalFormat = memoize(branding => {
      let options;
      switch (branding) {
       case InstantBranding:
        options = transformInstantOptions(internals.F, 1);
        break;

       case PlainDateTimeBranding:
        options = applyPlainFormatTimeZone(transformDateTimeOptions(internals.F, 1));
        break;

       case PlainDateBranding:
        options = applyPlainFormatTimeZone(transformDateOptions(internals.F, 1));
        break;

       case PlainTimeBranding:
        options = applyPlainFormatTimeZone(transformTimeOptions(internals.F, 1));
        break;

       case PlainYearMonthBranding:
        options = applyPlainFormatTimeZone(transformYearMonthOptions(internals.F, 1));
        break;

       case PlainMonthDayBranding:
        options = applyPlainFormatTimeZone(transformMonthDayOptions(internals.F, 1));
        break;

       default:
        throwTypeError(invalidFormatType(branding));
      }
      return new RawDateTimeFormat(internals.Ce, options);
    });
    return {
      A(formattable) {
        if (void 0 === formattable) {
          return [ internals.t ];
        }
        const brandingAndSlots = getTemporalBrandingAndSlots(formattable);
        if (!brandingAndSlots) {
          return [ internals.t, Number(formattable) ];
        }
        const [branding, slots] = brandingAndSlots;
        const format = getTemporalFormat(branding);
        return checkTemporalDateTimeFormatCompatible(format, branding, slots), [ format, temporalDateTimeToEpochMilli(branding, slots) ];
      },
      v(start, end) {
        void 0 !== start && void 0 !== end || throwTypeError(mismatchingFormatTypes);
        const startBrandingAndSlots = getTemporalBrandingAndSlots(start);
        const startEpochMilli = startBrandingAndSlots ? void 0 : Number(start);
        const endBrandingAndSlots = getTemporalBrandingAndSlots(end);
        const endEpochMilli = endBrandingAndSlots ? void 0 : Number(end);
        if (!startBrandingAndSlots && !endBrandingAndSlots) {
          return [ internals.t, startEpochMilli, endEpochMilli ];
        }
        startBrandingAndSlots && endBrandingAndSlots || throwTypeError(mismatchingFormatTypes);
        const [startBranding, startSlots] = startBrandingAndSlots;
        const [endBranding, endSlots] = endBrandingAndSlots;
        startBranding !== endBranding && throwTypeError(mismatchingFormatTypes);
        const format = getTemporalFormat(startBranding);
        return checkTemporalDateTimeFormatCompatible(format, startBranding, startSlots), 
        checkTemporalDateTimeFormatCompatible(format, startBranding, endSlots), [ format, temporalDateTimeToEpochMilli(startBranding, startSlots), temporalDateTimeToEpochMilli(startBranding, endSlots) ];
      }
    };
  });
}

function checkTemporalDateTimeFormatCompatible(format, branding, slots) {
  switch (branding) {
   case InstantBranding:
   case PlainTimeBranding:
    return;

   case PlainDateTimeBranding:
   case PlainDateBranding:
    return void checkResolvedCalendarCompatible(format, slots);

   case PlainYearMonthBranding:
   case PlainMonthDayBranding:
    return void checkResolvedCalendarCompatible(format, slots, 1);

   default:
    throwTypeError(invalidFormatType(branding));
  }
}

function temporalDateTimeToEpochMilli(branding, slots) {
  switch (branding) {
   case InstantBranding:
    return epochNanoToMilli(slots.epochNanoseconds);

   case PlainDateTimeBranding:
    return isoDateTimeToEpochMilli(slots);

   case PlainDateBranding:
   case PlainYearMonthBranding:
   case PlainMonthDayBranding:
    return isoDateToEpochMilli(slots);

   case PlainTimeBranding:
    return timeFieldsToMilli(slots);

   default:
    throwTypeError(invalidFormatType(branding));
  }
}

export { createDateTimeFormatClass, createIntlExtended };
