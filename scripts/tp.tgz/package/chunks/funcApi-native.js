import { NativeTemporal } from "./root.js";

import * as TemporalUtils from "temporal-utils";

import { defineTemporalClass, durationGetters, attachDebugString, timeGetters, dateFieldGetters$1 as dateFieldGetters, monthDayFieldGetters$1 as monthDayFieldGetters, yearMonthFieldGetters$1 as yearMonthFieldGetters } from "./apiHelpers.js";

import { RawDateTimeFormat, throwTypeError, invalidRelativeTo, normalizeUnitRoundOptions, coerceRoundingIncInteger, throwRangeError, invalidTimeZone, bindArgs } from "./internal.js";

import { DurationRecordBranding, getDurationSlots, getZonedDateTimeSlotsIfPresent, getPlainDateTimeSlotsIfPresent, getPlainDateSlotsIfPresent, setDurationSlots, getCalendarRecordImplCreator, getCalendarRecordId, PlainTimeRecordBranding, getPlainTimeSlots, setPlainTimeSlots, PlainDateTimeRecordBranding, getPlainDateTimeSlots, setPlainDateTimeSlots, PlainMonthDayRecordBranding, getPlainMonthDaySlots, setPlainMonthDaySlots, PlainYearMonthRecordBranding, getPlainYearMonthSlots, setPlainYearMonthSlots, PlainDateRecordBranding, getPlainDateSlots, setPlainDateSlots, ZonedDateTimeRecordBranding, getZonedDateTimeSlots, setZonedDateTimeSlots, InstantRecordBranding, getInstantSlots, setInstantSlots } from "./funcApi.js";

const RawDateTimeFormatClass = RawDateTimeFormat;

function createNativeDateTimeFormatFactory(getNative) {
  class NativeDateTimeFormat extends RawDateTimeFormatClass {
    format(record) {
      return super.format(getNative(record));
    }
    formatToParts(record) {
      return super.formatToParts(getNative(record));
    }
    formatRange(record0, record1) {
      return super.formatRange(getNative(record0), getNative(record1));
    }
    formatRangeToParts(record0, record1) {
      return super.formatRangeToParts(getNative(record0), getNative(record1));
    }
  }
  return (locales, options) => new NativeDateTimeFormat(locales, options);
}

const getNativeDuration = getDurationSlots;

const NativeDurationRecord = /*@__PURE__*/ defineTemporalClass(DurationRecordBranding, class {
  toJSON() {
    return getNativeDuration(this).toJSON();
  }
  valueOf() {
    return getNativeDuration(this).valueOf();
  }
}, getNativeDuration, durationGetters);

function createNativeDurationRecord(native) {
  const instance = Object.create(NativeDurationRecord.prototype);
  return setDurationSlots(instance, native), attachDebugString(instance), instance;
}

function create$7(years, months, weeks, days, hours, minutes, seconds, milliseconds, microseconds, nanoseconds) {
  return createNativeDurationRecord(new NativeTemporal.Duration(years, months, weeks, days, hours, minutes, seconds, milliseconds, microseconds, nanoseconds));
}

function fromFields$6(fields) {
  return createNativeDurationRecord(NativeTemporal.Duration.from(fields));
}

function fromString$7(s) {
  return createNativeDurationRecord(NativeTemporal.Duration.from(s));
}

function sign(duration) {
  return getNativeDuration(duration).sign;
}

function blank(duration) {
  return getNativeDuration(duration).blank;
}

function withFields$6(duration, mod) {
  return createNativeDurationRecord(getNativeDuration(duration).with(mod));
}

function negated(duration) {
  return createNativeDurationRecord(getNativeDuration(duration).negated());
}

function abs(duration) {
  return createNativeDurationRecord(getNativeDuration(duration).abs());
}

function add$6(duration, otherDuration) {
  const native = getNativeDuration(duration);
  const otherNative = getNativeDuration(otherDuration);
  return createNativeDurationRecord(native.add(otherNative));
}

function subtract$6(duration, otherDuration) {
  const native = getNativeDuration(duration);
  const otherNative = getNativeDuration(otherDuration);
  return createNativeDurationRecord(native.subtract(otherNative));
}

function round$4(duration, options) {
  const native = getNativeDuration(duration);
  return createNativeDurationRecord("string" == typeof options ? native.round(options) : native.round({
    ...options,
    relativeTo: refineRelativeTo(options?.relativeTo)
  }));
}

function total(duration, options) {
  const native = getNativeDuration(duration);
  if ("string" == typeof options) {
    return native.total(options);
  }
  const refinedOptions = {
    ...options,
    relativeTo: refineRelativeTo(options.relativeTo)
  };
  return native.total(refinedOptions);
}

function compare$6(duration, otherDuration, options) {
  const native = getNativeDuration(duration);
  const otherNative = getNativeDuration(otherDuration);
  return NativeTemporal.Duration.compare(native, otherNative, {
    ...options,
    relativeTo: refineRelativeTo(options?.relativeTo)
  });
}

function toLocaleString$7(duration, locales, options) {
  return Intl.DurationFormat ? new Intl.DurationFormat(locales, options).format(duration) : toString$7(duration);
}

function toString$7(duration, options) {
  return getNativeDuration(duration).toString(options);
}

function toBasicString$7(duration) {
  return getNativeDuration(duration).toString();
}

const toTemporal$7 = getNativeDuration;

function refineRelativeTo(arg) {
  if (arg) {
    const native = getZonedDateTimeSlotsIfPresent(arg) || getPlainDateTimeSlotsIfPresent(arg) || getPlainDateSlotsIfPresent(arg);
    if (native) {
      return native;
    }
    throwTypeError(invalidRelativeTo(arg));
  }
}

function createRoundToOptions(smallestUnit, options) {
  return {
    ...normalizeUnitRoundOptions(options),
    smallestUnit: smallestUnit
  };
}

function createCalendarRoundOptions(options) {
  const normOptions = normalizeUnitRoundOptions(options);
  return {
    ...normOptions,
    roundingIncrement: coerceRoundingIncInteger(normOptions)
  };
}

function requireTimeZoneId(timeZoneId) {
  return "string" == typeof timeZoneId && timeZoneId.includes("[") && throwRangeError(invalidTimeZone(timeZoneId)), 
  timeZoneId;
}

function refineNativeCalendarArgMaybe(calendarRecord) {
  if (void 0 !== calendarRecord) {
    return getValidatedCalendarId(calendarRecord);
  }
}

function runNativeCalendarResolver(canonicalCalendarId, getCalendarRecord) {
  getValidatedCalendarId(getCalendarRecord(canonicalCalendarId));
}

function getValidatedCalendarId(record) {
  return getCalendarRecordImplCreator(record), getCalendarRecordId(record);
}

const getNativePlainTime = getPlainTimeSlots;

const NativePlainTimeRecord = /*@__PURE__*/ defineTemporalClass(PlainTimeRecordBranding, class {
  toJSON() {
    return getNativePlainTime(this).toJSON();
  }
  valueOf() {
    return getNativePlainTime(this).valueOf();
  }
}, getNativePlainTime, timeGetters);

function createNativePlainTimeRecord(native) {
  const instance = Object.create(NativePlainTimeRecord.prototype);
  return setPlainTimeSlots(instance, native), attachDebugString(instance), instance;
}

function create$6(hour, minute, second, millisecond, microsecond, nanosecond) {
  return createNativePlainTimeRecord(new NativeTemporal.PlainTime(hour, minute, second, millisecond, microsecond, nanosecond));
}

function fromFields$5(fields, options) {
  return createNativePlainTimeRecord(NativeTemporal.PlainTime.from(fields, options));
}

function fromString$6(s) {
  return createNativePlainTimeRecord(NativeTemporal.PlainTime.from(s));
}

function withFields$5(record, mod, options) {
  return createNativePlainTimeRecord(getNativePlainTime(record).with(mod, options));
}

function add$5(record, duration) {
  const native = getNativePlainTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainTimeRecord(native.add(durationNative));
}

function subtract$5(record, duration) {
  const native = getNativePlainTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainTimeRecord(native.subtract(durationNative));
}

function diff$5(record, otherRecord, options) {
  const native = getNativePlainTime(record);
  const otherNative = getNativePlainTime(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function equals$6(record, otherRecord) {
  const native = getNativePlainTime(record);
  const otherNative = getNativePlainTime(otherRecord);
  return native.equals(otherNative);
}

function compare$5(record, otherRecord) {
  const native = getNativePlainTime(record);
  const otherNative = getNativePlainTime(otherRecord);
  return NativeTemporal.PlainTime.compare(native, otherNative);
}

const createFormat$5 = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativePlainTime);

function toLocaleString$6(record, locales, options) {
  return getNativePlainTime(record).toLocaleString(locales, options);
}

function toString$6(record, options) {
  return getNativePlainTime(record).toString(options);
}

function toBasicString$6(record) {
  return getNativePlainTime(record).toString();
}

const toTemporal$6 = getNativePlainTime;

function addHours$3(record, hours) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    hours: hours
  }));
}

function addMinutes$3(record, minutes) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    minutes: minutes
  }));
}

function addSeconds$3(record, seconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    seconds: seconds
  }));
}

function addMilliseconds$3(record, milliseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    milliseconds: milliseconds
  }));
}

function addMicroseconds$3(record, microseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    microseconds: microseconds
  }));
}

function addNanoseconds$3(record, nanoseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).add({
    nanoseconds: nanoseconds
  }));
}

function subtractHours$3(record, hours) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    hours: hours
  }));
}

function subtractMinutes$3(record, minutes) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    minutes: minutes
  }));
}

function subtractSeconds$3(record, seconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    seconds: seconds
  }));
}

function subtractMilliseconds$3(record, milliseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    milliseconds: milliseconds
  }));
}

function subtractMicroseconds$3(record, microseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    microseconds: microseconds
  }));
}

function subtractNanoseconds$3(record, nanoseconds) {
  return createNativePlainTimeRecord(getNativePlainTime(record).subtract({
    nanoseconds: nanoseconds
  }));
}

function roundToUnit$1(smallestUnit, record, options) {
  return ((record, options) => createNativePlainTimeRecord(getNativePlainTime(record).round(options)))(record, createRoundToOptions(smallestUnit, options));
}

const roundToHour$3 = /*@__PURE__*/ bindArgs(roundToUnit$1, "hour");

const roundToMinute$3 = /*@__PURE__*/ bindArgs(roundToUnit$1, "minute");

const roundToSecond$3 = /*@__PURE__*/ bindArgs(roundToUnit$1, "second");

const roundToMillisecond$3 = /*@__PURE__*/ bindArgs(roundToUnit$1, "millisecond");

const roundToMicrosecond$3 = /*@__PURE__*/ bindArgs(roundToUnit$1, "microsecond");

function startOfHour$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.startOfHour(getNativePlainTime(record)));
}

function startOfMinute$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.startOfMinute(getNativePlainTime(record)));
}

function startOfSecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.startOfSecond(getNativePlainTime(record)));
}

function startOfMillisecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.startOfMillisecond(getNativePlainTime(record)));
}

function startOfMicrosecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.startOfMicrosecond(getNativePlainTime(record)));
}

function endOfHour$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.endOfHour(getNativePlainTime(record)));
}

function endOfMinute$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.endOfMinute(getNativePlainTime(record)));
}

function endOfSecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.endOfSecond(getNativePlainTime(record)));
}

function endOfMillisecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.endOfMillisecond(getNativePlainTime(record)));
}

function endOfMicrosecond$2(record) {
  return createNativePlainTimeRecord(TemporalUtils.endOfMicrosecond(getNativePlainTime(record)));
}

function diffHours$3(record0, record1, options) {
  return TemporalUtils.diffHours(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

function diffMinutes$3(record0, record1, options) {
  return TemporalUtils.diffMinutes(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

function diffSeconds$3(record0, record1, options) {
  return TemporalUtils.diffSeconds(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

function diffMilliseconds$3(record0, record1, options) {
  return TemporalUtils.diffMilliseconds(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

function diffMicroseconds$3(record0, record1, options) {
  return TemporalUtils.diffMicroseconds(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

function diffNanoseconds$3(record0, record1, options) {
  return TemporalUtils.diffNanoseconds(getNativePlainTime(record0), getNativePlainTime(record1), options);
}

const getNativePlainDateTime = getPlainDateTimeSlots;

const NativePlainDateTimeRecord = /*@__PURE__*/ defineTemporalClass(PlainDateTimeRecordBranding, class {
  get calendarId() {
    return getNativePlainDateTime(this).calendarId;
  }
  toJSON() {
    return getNativePlainDateTime(this).toJSON();
  }
  valueOf() {
    return getNativePlainDateTime(this).valueOf();
  }
}, getNativePlainDateTime, dateFieldGetters, timeGetters);

function createNativePlainDateTimeRecord(native) {
  const instance = Object.create(NativePlainDateTimeRecord.prototype);
  return setPlainDateTimeSlots(instance, native), attachDebugString(instance), instance;
}

function create$5(isoYear, isoMonth, isoDay, hour, minute, second, millisecond, microsecond, nanosecond, calendar) {
  return createNativePlainDateTimeRecord(new NativeTemporal.PlainDateTime(isoYear, isoMonth, isoDay, hour, minute, second, millisecond, microsecond, nanosecond, refineNativeCalendarArgMaybe(calendar)));
}

function fromFields$4(fields, options) {
  const calendar = refineNativeCalendarArgMaybe(fields.calendar);
  return createNativePlainDateTimeRecord(NativeTemporal.PlainDateTime.from({
    ...fields,
    calendar: calendar
  }, options));
}

function fromString$5(s, getCalendarRecord) {
  const resNative = NativeTemporal.PlainDateTime.from(s);
  return runNativeCalendarResolver(resNative.calendarId, getCalendarRecord), createNativePlainDateTimeRecord(resNative);
}

function withCalendar$2(record, calendarRecord) {
  const native = getNativePlainDateTime(record);
  const calendarId = getValidatedCalendarId(calendarRecord);
  return createNativePlainDateTimeRecord(native.withCalendar(calendarId));
}

function withFields$4(record, mod, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).with(mod, options));
}

function withPlainTime$1(record, plainTimeRecord) {
  const native = getNativePlainDateTime(record);
  const plainTimeNative = void 0 === plainTimeRecord ? void 0 : getNativePlainTime(plainTimeRecord);
  return createNativePlainDateTimeRecord(native.withPlainTime(plainTimeNative));
}

function dayOfWeek$2(record) {
  return getNativePlainDateTime(record).dayOfWeek;
}

function daysInWeek$2(record) {
  return getNativePlainDateTime(record).daysInWeek;
}

function weekOfYear$2(record) {
  return getNativePlainDateTime(record).weekOfYear;
}

function yearOfWeek$2(record) {
  return getNativePlainDateTime(record).yearOfWeek;
}

function dayOfYear$2(record) {
  return getNativePlainDateTime(record).dayOfYear;
}

function daysInMonth$3(record) {
  return getNativePlainDateTime(record).daysInMonth;
}

function daysInYear$3(record) {
  return getNativePlainDateTime(record).daysInYear;
}

function monthsInYear$3(record) {
  return getNativePlainDateTime(record).monthsInYear;
}

function inLeapYear$3(record) {
  return getNativePlainDateTime(record).inLeapYear;
}

function add$4(record, duration, options) {
  const native = getNativePlainDateTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainDateTimeRecord(native.add(durationNative, options));
}

function subtract$4(record, duration, options) {
  const native = getNativePlainDateTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainDateTimeRecord(native.subtract(durationNative, options));
}

function diff$4(record, otherRecord, options) {
  const native = getNativePlainDateTime(record);
  const otherNative = getNativePlainDateTime(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function equals$5(record, otherRecord) {
  const native = getNativePlainDateTime(record);
  const otherNative = getNativePlainDateTime(otherRecord);
  return native.equals(otherNative);
}

function compare$4(record, otherRecord) {
  const native = getNativePlainDateTime(record);
  const otherNative = getNativePlainDateTime(otherRecord);
  return NativeTemporal.PlainDateTime.compare(native, otherNative);
}

const createFormat$4 = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativePlainDateTime);

function toLocaleString$5(record, locales, options) {
  return getNativePlainDateTime(record).toLocaleString(locales, options);
}

function toString$5(record, options) {
  return getNativePlainDateTime(record).toString(options);
}

function toBasicString$5(record) {
  return getNativePlainDateTime(record).toString();
}

function toZonedDateTime$1(record, timeZoneId, options) {
  return createNativeZonedDateTimeRecord(getNativePlainDateTime(record).toZonedDateTime(requireTimeZoneId(timeZoneId), options));
}

function toPlainDate$3(record) {
  return createNativePlainDateRecord(getNativePlainDateTime(record).toPlainDate());
}

function toPlainTime$1(record) {
  return createNativePlainTimeRecord(getNativePlainDateTime(record).toPlainTime());
}

const toTemporal$5 = getNativePlainDateTime;

function withDayOfYear$2(record, dayOfYear, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.withDayOfYear(getNativePlainDateTime(record), dayOfYear, options));
}

function withDayOfMonth$2(record, dayOfMonth, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).with({
    day: dayOfMonth
  }, options));
}

function withDayOfWeek$2(record, dayOfWeek, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.withDayOfWeek(getNativePlainDateTime(record), dayOfWeek, options));
}

function withWeekOfYear$2(record, weekOfYear, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.withWeekOfYear(getNativePlainDateTime(record), weekOfYear, options));
}

function addYears$3(record, years, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    years: years
  }, options));
}

function addMonths$3(record, months, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    months: months
  }, options));
}

function addWeeks$2(record, weeks) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    weeks: weeks
  }));
}

function addDays$2(record, days) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    days: days
  }));
}

function addHours$2(record, hours) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    hours: hours
  }));
}

function addMinutes$2(record, minutes) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    minutes: minutes
  }));
}

function addSeconds$2(record, seconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    seconds: seconds
  }));
}

function addMilliseconds$2(record, milliseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    milliseconds: milliseconds
  }));
}

function addMicroseconds$2(record, microseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    microseconds: microseconds
  }));
}

function addNanoseconds$2(record, nanoseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).add({
    nanoseconds: nanoseconds
  }));
}

function subtractYears$3(record, years, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    years: years
  }, options));
}

function subtractMonths$3(record, months, options) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    months: months
  }, options));
}

function subtractWeeks$2(record, weeks) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    weeks: weeks
  }));
}

function subtractDays$2(record, days) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    days: days
  }));
}

function subtractHours$2(record, hours) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    hours: hours
  }));
}

function subtractMinutes$2(record, minutes) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    minutes: minutes
  }));
}

function subtractSeconds$2(record, seconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    seconds: seconds
  }));
}

function subtractMilliseconds$2(record, milliseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    milliseconds: milliseconds
  }));
}

function subtractMicroseconds$2(record, microseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    microseconds: microseconds
  }));
}

function subtractNanoseconds$2(record, nanoseconds) {
  return createNativePlainDateTimeRecord(getNativePlainDateTime(record).subtract({
    nanoseconds: nanoseconds
  }));
}

function roundToYear$3(record, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.roundToYear(getNativePlainDateTime(record), createCalendarRoundOptions(options)));
}

function roundToMonth$2(record, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.roundToMonth(getNativePlainDateTime(record), createCalendarRoundOptions(options)));
}

function roundToWeek$2(record, options) {
  return createNativePlainDateTimeRecord(TemporalUtils.roundToWeek(getNativePlainDateTime(record), createCalendarRoundOptions(options)));
}

function roundToDayTimeUnit$1(smallestUnit, record, options) {
  return ((record, options) => createNativePlainDateTimeRecord(getNativePlainDateTime(record).round(options)))(record, createRoundToOptions(smallestUnit, options));
}

const roundToDay$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "day");

const roundToHour$2 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "hour");

const roundToMinute$2 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "minute");

const roundToSecond$2 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "second");

const roundToMillisecond$2 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "millisecond");

const roundToMicrosecond$2 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit$1, "microsecond");

function startOfYear$3(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfYear(getNativePlainDateTime(record)));
}

function startOfMonth$2(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfMonth(getNativePlainDateTime(record)));
}

function startOfWeek$2(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfWeek(getNativePlainDateTime(record)));
}

function startOfDay$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfDay(getNativePlainDateTime(record)));
}

function startOfHour$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfHour(getNativePlainDateTime(record)));
}

function startOfMinute$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfMinute(getNativePlainDateTime(record)));
}

function startOfSecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfSecond(getNativePlainDateTime(record)));
}

function startOfMillisecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfMillisecond(getNativePlainDateTime(record)));
}

function startOfMicrosecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.startOfMicrosecond(getNativePlainDateTime(record)));
}

function endOfYear$3(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfYear(getNativePlainDateTime(record)));
}

function endOfMonth$2(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfMonth(getNativePlainDateTime(record)));
}

function endOfWeek$2(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfWeek(getNativePlainDateTime(record)));
}

function endOfDay$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfDay(getNativePlainDateTime(record)));
}

function endOfHour$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfHour(getNativePlainDateTime(record)));
}

function endOfMinute$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfMinute(getNativePlainDateTime(record)));
}

function endOfSecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfSecond(getNativePlainDateTime(record)));
}

function endOfMillisecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfMillisecond(getNativePlainDateTime(record)));
}

function endOfMicrosecond$1(record) {
  return createNativePlainDateTimeRecord(TemporalUtils.endOfMicrosecond(getNativePlainDateTime(record)));
}

function diffYears$3(record0, record1, options) {
  return TemporalUtils.diffYears(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffMonths$3(record0, record1, options) {
  return TemporalUtils.diffMonths(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffWeeks$2(record0, record1, options) {
  return TemporalUtils.diffWeeks(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffDays$2(record0, record1, options) {
  return TemporalUtils.diffDays(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffHours$2(record0, record1, options) {
  return TemporalUtils.diffHours(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffMinutes$2(record0, record1, options) {
  return TemporalUtils.diffMinutes(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffSeconds$2(record0, record1, options) {
  return TemporalUtils.diffSeconds(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffMilliseconds$2(record0, record1, options) {
  return TemporalUtils.diffMilliseconds(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffMicroseconds$2(record0, record1, options) {
  return TemporalUtils.diffMicroseconds(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

function diffNanoseconds$2(record0, record1, options) {
  return TemporalUtils.diffNanoseconds(getNativePlainDateTime(record0), getNativePlainDateTime(record1), options);
}

const getNativePlainMonthDay = getPlainMonthDaySlots;

const NativePlainMonthDayRecord = /*@__PURE__*/ defineTemporalClass(PlainMonthDayRecordBranding, class {
  get calendarId() {
    return getNativePlainMonthDay(this).calendarId;
  }
  toJSON() {
    return getNativePlainMonthDay(this).toJSON();
  }
  valueOf() {
    return getNativePlainMonthDay(this).valueOf();
  }
}, getNativePlainMonthDay, monthDayFieldGetters);

function createNativePlainMonthDayRecord(native) {
  const instance = Object.create(NativePlainMonthDayRecord.prototype);
  return setPlainMonthDaySlots(instance, native), attachDebugString(instance), instance;
}

function create$4(isoMonth, isoDay, calendar, referenceIsoYear) {
  return createNativePlainMonthDayRecord(new NativeTemporal.PlainMonthDay(isoMonth, isoDay, refineNativeCalendarArgMaybe(calendar), referenceIsoYear));
}

function fromFields$3(fields, options) {
  const calendar = refineNativeCalendarArgMaybe(fields.calendar);
  return createNativePlainMonthDayRecord(NativeTemporal.PlainMonthDay.from({
    ...fields,
    calendar: calendar
  }, options));
}

function fromString$4(s, getCalendarRecord) {
  const resNative = NativeTemporal.PlainMonthDay.from(s);
  return runNativeCalendarResolver(resNative.calendarId, getCalendarRecord), createNativePlainMonthDayRecord(resNative);
}

function withFields$3(record, mod, options) {
  return createNativePlainMonthDayRecord(getNativePlainMonthDay(record).with(mod, options));
}

function equals$4(record, otherRecord) {
  const native = getNativePlainMonthDay(record);
  const otherNative = getNativePlainMonthDay(otherRecord);
  return native.equals(otherNative);
}

const createFormat$3 = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativePlainMonthDay);

function toLocaleString$4(record, locales, options) {
  return getNativePlainMonthDay(record).toLocaleString(locales, options);
}

function toString$4(record, options) {
  return getNativePlainMonthDay(record).toString(options);
}

function toBasicString$4(record) {
  return getNativePlainMonthDay(record).toString();
}

function toPlainDate$2(record, fields) {
  return createNativePlainDateRecord(getNativePlainMonthDay(record).toPlainDate(fields));
}

const toTemporal$4 = getNativePlainMonthDay;

const getNativePlainYearMonth = getPlainYearMonthSlots;

const NativePlainYearMonthRecord = /*@__PURE__*/ defineTemporalClass(PlainYearMonthRecordBranding, class {
  get calendarId() {
    return getNativePlainYearMonth(this).calendarId;
  }
  toJSON() {
    return getNativePlainYearMonth(this).toJSON();
  }
  valueOf() {
    return getNativePlainYearMonth(this).valueOf();
  }
}, getNativePlainYearMonth, yearMonthFieldGetters);

function createNativePlainYearMonthRecord(native) {
  const instance = Object.create(NativePlainYearMonthRecord.prototype);
  return setPlainYearMonthSlots(instance, native), attachDebugString(instance), instance;
}

function create$3(isoYear, isoMonth, calendar, referenceIsoDay) {
  return createNativePlainYearMonthRecord(new NativeTemporal.PlainYearMonth(isoYear, isoMonth, refineNativeCalendarArgMaybe(calendar), referenceIsoDay));
}

function fromFields$2(fields, options) {
  const calendar = refineNativeCalendarArgMaybe(fields.calendar);
  return createNativePlainYearMonthRecord(NativeTemporal.PlainYearMonth.from({
    ...fields,
    calendar: calendar
  }, options));
}

function fromString$3(s, getCalendarRecord) {
  const resNative = NativeTemporal.PlainYearMonth.from(s);
  return runNativeCalendarResolver(resNative.calendarId, getCalendarRecord), createNativePlainYearMonthRecord(resNative);
}

function daysInMonth$2(record) {
  return getNativePlainYearMonth(record).daysInMonth;
}

function daysInYear$2(record) {
  return getNativePlainYearMonth(record).daysInYear;
}

function monthsInYear$2(record) {
  return getNativePlainYearMonth(record).monthsInYear;
}

function inLeapYear$2(record) {
  return getNativePlainYearMonth(record).inLeapYear;
}

function withFields$2(record, mod, options) {
  return createNativePlainYearMonthRecord(getNativePlainYearMonth(record).with(mod, options));
}

function add$3(record, duration, options) {
  const native = getNativePlainYearMonth(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainYearMonthRecord(native.add(durationNative, options));
}

function subtract$3(record, duration, options) {
  const native = getNativePlainYearMonth(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainYearMonthRecord(native.subtract(durationNative, options));
}

function diff$3(record, otherRecord, options) {
  const native = getNativePlainYearMonth(record);
  const otherNative = getNativePlainYearMonth(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function equals$3(record, otherRecord) {
  const native = getNativePlainYearMonth(record);
  const otherNative = getNativePlainYearMonth(otherRecord);
  return native.equals(otherNative);
}

function compare$3(record, otherRecord) {
  const native = getNativePlainYearMonth(record);
  const otherNative = getNativePlainYearMonth(otherRecord);
  return NativeTemporal.PlainYearMonth.compare(native, otherNative);
}

const createFormat$2 = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativePlainYearMonth);

function toLocaleString$3(record, locales, options) {
  return getNativePlainYearMonth(record).toLocaleString(locales, options);
}

function toString$3(record, options) {
  return getNativePlainYearMonth(record).toString(options);
}

function toBasicString$3(record) {
  return getNativePlainYearMonth(record).toString();
}

function toPlainDate$1(record, fields) {
  return createNativePlainDateRecord(getNativePlainYearMonth(record).toPlainDate(fields));
}

const toTemporal$3 = getNativePlainYearMonth;

function addYears$2(record, years, options) {
  return createNativePlainYearMonthRecord(getNativePlainYearMonth(record).add({
    years: years
  }, options));
}

function addMonths$2(record, months, options) {
  return createNativePlainYearMonthRecord(getNativePlainYearMonth(record).add({
    months: months
  }, options));
}

function subtractYears$2(record, years, options) {
  return createNativePlainYearMonthRecord(getNativePlainYearMonth(record).subtract({
    years: years
  }, options));
}

function subtractMonths$2(record, months, options) {
  return createNativePlainYearMonthRecord(getNativePlainYearMonth(record).subtract({
    months: months
  }, options));
}

function roundToYear$2(record, options) {
  return createNativePlainYearMonthRecord(TemporalUtils.roundToYear(getNativePlainYearMonth(record), createCalendarRoundOptions(options)));
}

function startOfYear$2(record) {
  return createNativePlainYearMonthRecord(TemporalUtils.startOfYear(getNativePlainYearMonth(record)));
}

function endOfYear$2(record) {
  return createNativePlainYearMonthRecord(TemporalUtils.endOfYear(getNativePlainYearMonth(record)));
}

function diffYears$2(record0, record1, options) {
  return TemporalUtils.diffYears(getNativePlainYearMonth(record0), getNativePlainYearMonth(record1), options);
}

function diffMonths$2(record0, record1, options) {
  return TemporalUtils.diffMonths(getNativePlainYearMonth(record0), getNativePlainYearMonth(record1), options);
}

const getNativePlainDate = getPlainDateSlots;

const NativePlainDateRecord = /*@__PURE__*/ defineTemporalClass(PlainDateRecordBranding, class {
  get calendarId() {
    return getNativePlainDate(this).calendarId;
  }
  toJSON() {
    return getNativePlainDate(this).toJSON();
  }
  valueOf() {
    return getNativePlainDate(this).valueOf();
  }
}, getNativePlainDate, dateFieldGetters);

function createNativePlainDateRecord(native) {
  const instance = Object.create(NativePlainDateRecord.prototype);
  return setPlainDateSlots(instance, native), attachDebugString(instance), instance;
}

function create$2(isoYear, isoMonth, isoDay, calendar) {
  return createNativePlainDateRecord(new NativeTemporal.PlainDate(isoYear, isoMonth, isoDay, refineNativeCalendarArgMaybe(calendar)));
}

function fromFields$1(fields, options) {
  const calendar = refineNativeCalendarArgMaybe(fields.calendar);
  return createNativePlainDateRecord(NativeTemporal.PlainDate.from({
    ...fields,
    calendar: calendar
  }, options));
}

function fromString$2(s, getCalendarRecord) {
  const resNative = NativeTemporal.PlainDate.from(s);
  return runNativeCalendarResolver(resNative.calendarId, getCalendarRecord), createNativePlainDateRecord(resNative);
}

function dayOfWeek$1(record) {
  return getNativePlainDate(record).dayOfWeek;
}

function daysInWeek$1(record) {
  return getNativePlainDate(record).daysInWeek;
}

function weekOfYear$1(record) {
  return getNativePlainDate(record).weekOfYear;
}

function yearOfWeek$1(record) {
  return getNativePlainDate(record).yearOfWeek;
}

function dayOfYear$1(record) {
  return getNativePlainDate(record).dayOfYear;
}

function daysInMonth$1(record) {
  return getNativePlainDate(record).daysInMonth;
}

function daysInYear$1(record) {
  return getNativePlainDate(record).daysInYear;
}

function monthsInYear$1(record) {
  return getNativePlainDate(record).monthsInYear;
}

function inLeapYear$1(record) {
  return getNativePlainDate(record).inLeapYear;
}

function withFields$1(record, mod, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).with(mod, options));
}

function withCalendar$1(record, calendarRecord) {
  const native = getNativePlainDate(record);
  const calendarId = getValidatedCalendarId(calendarRecord);
  return createNativePlainDateRecord(native.withCalendar(calendarId));
}

function add$2(record, duration, options) {
  const native = getNativePlainDate(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainDateRecord(native.add(durationNative, options));
}

function subtract$2(record, duration, options) {
  const native = getNativePlainDate(record);
  const durationNative = getNativeDuration(duration);
  return createNativePlainDateRecord(native.subtract(durationNative, options));
}

function diff$2(record, otherRecord, options) {
  const native = getNativePlainDate(record);
  const otherNative = getNativePlainDate(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function equals$2(record, otherRecord) {
  const native = getNativePlainDate(record);
  const otherNative = getNativePlainDate(otherRecord);
  return native.equals(otherNative);
}

function compare$2(record, otherRecord) {
  const native = getNativePlainDate(record);
  const otherNative = getNativePlainDate(otherRecord);
  return NativeTemporal.PlainDate.compare(native, otherNative);
}

const createFormat$1 = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativePlainDate);

function toLocaleString$2(record, locales, options) {
  return getNativePlainDate(record).toLocaleString(locales, options);
}

function toString$2(record, options) {
  return getNativePlainDate(record).toString(options);
}

function toBasicString$2(record) {
  return getNativePlainDate(record).toString();
}

function toZonedDateTime(record, options) {
  const native = getNativePlainDate(record);
  const optionsObj = "string" == typeof options ? {
    timeZone: options
  } : {
    ...options,
    plainTime: void 0 === options.plainTime ? void 0 : getNativePlainTime(options.plainTime)
  };
  return requireTimeZoneId(optionsObj.timeZone), createNativeZonedDateTimeRecord(native.toZonedDateTime(optionsObj));
}

function toPlainDateTime$1(record, plainTimeRecord) {
  const native = getNativePlainDate(record);
  const plainTimeNative = void 0 === plainTimeRecord ? void 0 : getNativePlainTime(plainTimeRecord);
  return createNativePlainDateTimeRecord(native.toPlainDateTime(plainTimeNative));
}

function toPlainYearMonth(record) {
  return createNativePlainYearMonthRecord(getNativePlainDate(record).toPlainYearMonth());
}

function toPlainMonthDay(record) {
  return createNativePlainMonthDayRecord(getNativePlainDate(record).toPlainMonthDay());
}

const toTemporal$2 = getNativePlainDate;

function withDayOfYear$1(record, dayOfYear, options) {
  return createNativePlainDateRecord(TemporalUtils.withDayOfYear(getNativePlainDate(record), dayOfYear, options));
}

function withDayOfMonth$1(record, dayOfMonth, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).with({
    day: dayOfMonth
  }, options));
}

function withDayOfWeek$1(record, dayOfWeek, options) {
  return createNativePlainDateRecord(TemporalUtils.withDayOfWeek(getNativePlainDate(record), dayOfWeek, options));
}

function withWeekOfYear$1(record, weekOfYear, options) {
  return createNativePlainDateRecord(TemporalUtils.withWeekOfYear(getNativePlainDate(record), weekOfYear, options));
}

function addYears$1(record, years, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).add({
    years: years
  }, options));
}

function addMonths$1(record, months, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).add({
    months: months
  }, options));
}

function addWeeks$1(record, weeks) {
  return createNativePlainDateRecord(getNativePlainDate(record).add({
    weeks: weeks
  }));
}

function addDays$1(record, days) {
  return createNativePlainDateRecord(getNativePlainDate(record).add({
    days: days
  }));
}

function subtractYears$1(record, years, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).subtract({
    years: years
  }, options));
}

function subtractMonths$1(record, months, options) {
  return createNativePlainDateRecord(getNativePlainDate(record).subtract({
    months: months
  }, options));
}

function subtractWeeks$1(record, weeks) {
  return createNativePlainDateRecord(getNativePlainDate(record).subtract({
    weeks: weeks
  }));
}

function subtractDays$1(record, days) {
  return createNativePlainDateRecord(getNativePlainDate(record).subtract({
    days: days
  }));
}

function roundToYear$1(record, options) {
  return createNativePlainDateRecord(TemporalUtils.roundToYear(getNativePlainDate(record), createCalendarRoundOptions(options)));
}

function roundToMonth$1(record, options) {
  return createNativePlainDateRecord(TemporalUtils.roundToMonth(getNativePlainDate(record), createCalendarRoundOptions(options)));
}

function roundToWeek$1(record, options) {
  return createNativePlainDateRecord(TemporalUtils.roundToWeek(getNativePlainDate(record), createCalendarRoundOptions(options)));
}

function startOfYear$1(record) {
  return createNativePlainDateRecord(TemporalUtils.startOfYear(getNativePlainDate(record)));
}

function startOfMonth$1(record) {
  return createNativePlainDateRecord(TemporalUtils.startOfMonth(getNativePlainDate(record)));
}

function startOfWeek$1(record) {
  return createNativePlainDateRecord(TemporalUtils.startOfWeek(getNativePlainDate(record)));
}

function endOfYear$1(record) {
  return createNativePlainDateRecord(TemporalUtils.endOfYear(getNativePlainDate(record)));
}

function endOfMonth$1(record) {
  return createNativePlainDateRecord(TemporalUtils.endOfMonth(getNativePlainDate(record)));
}

function endOfWeek$1(record) {
  return createNativePlainDateRecord(TemporalUtils.endOfWeek(getNativePlainDate(record)));
}

function diffYears$1(record0, record1, options) {
  return TemporalUtils.diffYears(getNativePlainDate(record0), getNativePlainDate(record1), options);
}

function diffMonths$1(record0, record1, options) {
  return TemporalUtils.diffMonths(getNativePlainDate(record0), getNativePlainDate(record1), options);
}

function diffWeeks$1(record0, record1, options) {
  return TemporalUtils.diffWeeks(getNativePlainDate(record0), getNativePlainDate(record1), options);
}

function diffDays$1(record0, record1, options) {
  return TemporalUtils.diffDays(getNativePlainDate(record0), getNativePlainDate(record1), options);
}

const getNativeZonedDateTime = getZonedDateTimeSlots;

const NativeZonedDateTimeRecord = /*@__PURE__*/ defineTemporalClass(ZonedDateTimeRecordBranding, class {
  get calendarId() {
    return getNativeZonedDateTime(this).calendarId;
  }
  get timeZoneId() {
    return getNativeZonedDateTime(this).timeZoneId;
  }
  get epochMilliseconds() {
    return getNativeZonedDateTime(this).epochMilliseconds;
  }
  get epochNanoseconds() {
    return getNativeZonedDateTime(this).epochNanoseconds;
  }
  toJSON() {
    return getNativeZonedDateTime(this).toJSON();
  }
  valueOf() {
    return getNativeZonedDateTime(this).valueOf();
  }
}, getNativeZonedDateTime, dateFieldGetters, timeGetters);

function createNativeZonedDateTimeRecord(native) {
  const instance = Object.create(NativeZonedDateTimeRecord.prototype);
  return setZonedDateTimeSlots(instance, native), attachDebugString(instance), instance;
}

function create$1(epochNanoseconds, timeZoneId, calendar) {
  return createNativeZonedDateTimeRecord(new NativeTemporal.ZonedDateTime(epochNanoseconds, timeZoneId, refineNativeCalendarArgMaybe(calendar)));
}

function fromFields(fields, options) {
  const calendar = refineNativeCalendarArgMaybe(fields.calendar);
  return requireTimeZoneId(fields.timeZone), createNativeZonedDateTimeRecord(NativeTemporal.ZonedDateTime.from({
    ...fields,
    calendar: calendar
  }, options));
}

function fromString$1(s, getCalendarRecord, options) {
  const resNative = NativeTemporal.ZonedDateTime.from(s, options);
  return runNativeCalendarResolver(resNative.calendarId, getCalendarRecord), createNativeZonedDateTimeRecord(resNative);
}

function withFields(record, mod, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).with(mod, options));
}

function withCalendar(record, calendarRecord) {
  const native = getNativeZonedDateTime(record);
  const calendarId = getValidatedCalendarId(calendarRecord);
  return createNativeZonedDateTimeRecord(native.withCalendar(calendarId));
}

function withTimeZone(record, timeZoneId) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).withTimeZone(requireTimeZoneId(timeZoneId)));
}

function withPlainTime(record, plainTimeRecord) {
  const native = getNativeZonedDateTime(record);
  const plainTimeNative = void 0 === plainTimeRecord ? void 0 : getNativePlainTime(plainTimeRecord);
  return createNativeZonedDateTimeRecord(native.withPlainTime(plainTimeNative));
}

function offsetNanoseconds(record) {
  return getNativeZonedDateTime(record).offsetNanoseconds;
}

function offset(record) {
  return getNativeZonedDateTime(record).offset;
}

function dayOfWeek(record) {
  return getNativeZonedDateTime(record).dayOfWeek;
}

function daysInWeek(record) {
  return getNativeZonedDateTime(record).daysInWeek;
}

function weekOfYear(record) {
  return getNativeZonedDateTime(record).weekOfYear;
}

function yearOfWeek(record) {
  return getNativeZonedDateTime(record).yearOfWeek;
}

function dayOfYear(record) {
  return getNativeZonedDateTime(record).dayOfYear;
}

function daysInMonth(record) {
  return getNativeZonedDateTime(record).daysInMonth;
}

function daysInYear(record) {
  return getNativeZonedDateTime(record).daysInYear;
}

function monthsInYear(record) {
  return getNativeZonedDateTime(record).monthsInYear;
}

function inLeapYear(record) {
  return getNativeZonedDateTime(record).inLeapYear;
}

function hoursInDay(record) {
  return getNativeZonedDateTime(record).hoursInDay;
}

function toString$1(record, options) {
  return getNativeZonedDateTime(record).toString(options);
}

function toBasicString$1(record) {
  return getNativeZonedDateTime(record).toString();
}

function add$1(record, duration, options) {
  const native = getNativeZonedDateTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativeZonedDateTimeRecord(native.add(durationNative, options));
}

function subtract$1(record, duration, options) {
  const native = getNativeZonedDateTime(record);
  const durationNative = getNativeDuration(duration);
  return createNativeZonedDateTimeRecord(native.subtract(durationNative, options));
}

function diff$1(record, otherRecord, options) {
  const native = getNativeZonedDateTime(record);
  const otherNative = getNativeZonedDateTime(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function startOfDay(record) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).startOfDay());
}

function getTimeZoneTransition(record, options) {
  const resNative = getNativeZonedDateTime(record).getTimeZoneTransition(options);
  return resNative ? createNativeZonedDateTimeRecord(resNative) : null;
}

function equals$1(record, otherRecord) {
  const native = getNativeZonedDateTime(record);
  const otherNative = getNativeZonedDateTime(otherRecord);
  return native.equals(otherNative);
}

function compare$1(record, otherRecord) {
  const native = getNativeZonedDateTime(record);
  const otherNative = getNativeZonedDateTime(otherRecord);
  return NativeTemporal.ZonedDateTime.compare(native, otherNative);
}

function toLocaleString$1(record, locales, options) {
  return getNativeZonedDateTime(record).toLocaleString(locales, options);
}

function toInstant(record) {
  return createNativeInstantRecord(getNativeZonedDateTime(record).toInstant());
}

function toPlainDateTime(record) {
  return createNativePlainDateTimeRecord(getNativeZonedDateTime(record).toPlainDateTime());
}

function toPlainDate(record) {
  return createNativePlainDateRecord(getNativeZonedDateTime(record).toPlainDate());
}

function toPlainTime(record) {
  return createNativePlainTimeRecord(getNativeZonedDateTime(record).toPlainTime());
}

const toTemporal$1 = getNativeZonedDateTime;

function withDayOfYear(record, dayOfYear, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.withDayOfYear(getNativeZonedDateTime(record), dayOfYear, options));
}

function withDayOfMonth(record, dayOfMonth, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).with({
    day: dayOfMonth
  }, options));
}

function withDayOfWeek(record, dayOfWeek, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.withDayOfWeek(getNativeZonedDateTime(record), dayOfWeek, options));
}

function withWeekOfYear(record, weekOfYear, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.withWeekOfYear(getNativeZonedDateTime(record), weekOfYear, options));
}

function addYears(record, years, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    years: years
  }, options));
}

function addMonths(record, months, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    months: months
  }, options));
}

function addWeeks(record, weeks) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    weeks: weeks
  }));
}

function addDays(record, days) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    days: days
  }));
}

function addHours$1(record, hours) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    hours: hours
  }));
}

function addMinutes$1(record, minutes) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    minutes: minutes
  }));
}

function addSeconds$1(record, seconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    seconds: seconds
  }));
}

function addMilliseconds$1(record, milliseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    milliseconds: milliseconds
  }));
}

function addMicroseconds$1(record, microseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    microseconds: microseconds
  }));
}

function addNanoseconds$1(record, nanoseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).add({
    nanoseconds: nanoseconds
  }));
}

function subtractYears(record, years, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    years: years
  }, options));
}

function subtractMonths(record, months, options) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    months: months
  }, options));
}

function subtractWeeks(record, weeks) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    weeks: weeks
  }));
}

function subtractDays(record, days) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    days: days
  }));
}

function subtractHours$1(record, hours) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    hours: hours
  }));
}

function subtractMinutes$1(record, minutes) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    minutes: minutes
  }));
}

function subtractSeconds$1(record, seconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    seconds: seconds
  }));
}

function subtractMilliseconds$1(record, milliseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    milliseconds: milliseconds
  }));
}

function subtractMicroseconds$1(record, microseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    microseconds: microseconds
  }));
}

function subtractNanoseconds$1(record, nanoseconds) {
  return createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).subtract({
    nanoseconds: nanoseconds
  }));
}

function roundToYear(record, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.roundToYear(getNativeZonedDateTime(record), createCalendarRoundOptions(options)));
}

function roundToMonth(record, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.roundToMonth(getNativeZonedDateTime(record), createCalendarRoundOptions(options)));
}

function roundToWeek(record, options) {
  return createNativeZonedDateTimeRecord(TemporalUtils.roundToWeek(getNativeZonedDateTime(record), createCalendarRoundOptions(options)));
}

function roundToDayTimeUnit(smallestUnit, record, options) {
  return ((record, options) => createNativeZonedDateTimeRecord(getNativeZonedDateTime(record).round(options)))(record, createRoundToOptions(smallestUnit, options));
}

const roundToDay = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "day");

const roundToHour$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "hour");

const roundToMinute$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "minute");

const roundToSecond$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "second");

const roundToMillisecond$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "millisecond");

const roundToMicrosecond$1 = /*@__PURE__*/ bindArgs(roundToDayTimeUnit, "microsecond");

function startOfYear(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfYear(getNativeZonedDateTime(record)));
}

function startOfMonth(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfMonth(getNativeZonedDateTime(record)));
}

function startOfWeek(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfWeek(getNativeZonedDateTime(record)));
}

function startOfHour(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfHour(getNativeZonedDateTime(record)));
}

function startOfMinute(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfMinute(getNativeZonedDateTime(record)));
}

function startOfSecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfSecond(getNativeZonedDateTime(record)));
}

function startOfMillisecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfMillisecond(getNativeZonedDateTime(record)));
}

function startOfMicrosecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.startOfMicrosecond(getNativeZonedDateTime(record)));
}

function endOfYear(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfYear(getNativeZonedDateTime(record)));
}

function endOfMonth(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfMonth(getNativeZonedDateTime(record)));
}

function endOfWeek(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfWeek(getNativeZonedDateTime(record)));
}

function endOfDay(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfDay(getNativeZonedDateTime(record)));
}

function endOfHour(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfHour(getNativeZonedDateTime(record)));
}

function endOfMinute(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfMinute(getNativeZonedDateTime(record)));
}

function endOfSecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfSecond(getNativeZonedDateTime(record)));
}

function endOfMillisecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfMillisecond(getNativeZonedDateTime(record)));
}

function endOfMicrosecond(record) {
  return createNativeZonedDateTimeRecord(TemporalUtils.endOfMicrosecond(getNativeZonedDateTime(record)));
}

function diffYears(record0, record1, options) {
  return TemporalUtils.diffYears(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffMonths(record0, record1, options) {
  return TemporalUtils.diffMonths(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffWeeks(record0, record1, options) {
  return TemporalUtils.diffWeeks(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffDays(record0, record1, options) {
  return TemporalUtils.diffDays(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffHours$1(record0, record1, options) {
  return TemporalUtils.diffHours(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffMinutes$1(record0, record1, options) {
  return TemporalUtils.diffMinutes(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffSeconds$1(record0, record1, options) {
  return TemporalUtils.diffSeconds(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffMilliseconds$1(record0, record1, options) {
  return TemporalUtils.diffMilliseconds(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffMicroseconds$1(record0, record1, options) {
  return TemporalUtils.diffMicroseconds(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

function diffNanoseconds$1(record0, record1, options) {
  return TemporalUtils.diffNanoseconds(getNativeZonedDateTime(record0), getNativeZonedDateTime(record1), options);
}

const getNativeInstant = getInstantSlots;

const NativeInstantRecord = /*@__PURE__*/ defineTemporalClass(InstantRecordBranding, class {
  get epochMilliseconds() {
    return getNativeInstant(this).epochMilliseconds;
  }
  get epochNanoseconds() {
    return getNativeInstant(this).epochNanoseconds;
  }
  toJSON() {
    return getNativeInstant(this).toJSON();
  }
  valueOf() {
    return getNativeInstant(this).valueOf();
  }
});

function createNativeInstantRecord(native) {
  const instance = Object.create(NativeInstantRecord.prototype);
  return setInstantSlots(instance, native), attachDebugString(instance), instance;
}

function create(epochNanoseconds) {
  return createNativeInstantRecord(new NativeTemporal.Instant(epochNanoseconds));
}

function fromEpochMilliseconds(epochMilliseconds) {
  return createNativeInstantRecord(NativeTemporal.Instant.fromEpochMilliseconds(epochMilliseconds));
}

function fromEpochNanoseconds(epochNanoseconds) {
  return createNativeInstantRecord(NativeTemporal.Instant.fromEpochNanoseconds(epochNanoseconds));
}

function fromString(s) {
  return createNativeInstantRecord(NativeTemporal.Instant.from(s));
}

function add(record, durationRecord) {
  const native = getNativeInstant(record);
  const durationNative = getNativeDuration(durationRecord);
  return createNativeInstantRecord(native.add(durationNative));
}

function subtract(record, durationRecord) {
  const native = getNativeInstant(record);
  const durationNative = getNativeDuration(durationRecord);
  return createNativeInstantRecord(native.subtract(durationNative));
}

function diff(record, otherRecord, options) {
  const native = getNativeInstant(record);
  const otherNative = getNativeInstant(otherRecord);
  return createNativeDurationRecord(native.until(otherNative, options));
}

function equals(record, otherRecord) {
  const native = getNativeInstant(record);
  const otherNative = getNativeInstant(otherRecord);
  return native.equals(otherNative);
}

function compare(record, otherRecord) {
  const native = getNativeInstant(record);
  const otherNative = getNativeInstant(otherRecord);
  return NativeTemporal.Instant.compare(native, otherNative);
}

function toZonedDateTimeISO(record, timeZoneId) {
  return createNativeZonedDateTimeRecord(getNativeInstant(record).toZonedDateTimeISO(requireTimeZoneId(timeZoneId)));
}

const createFormat = /*@__PURE__*/ createNativeDateTimeFormatFactory(getNativeInstant);

function toLocaleString(record, locales, options) {
  return getNativeInstant(record).toLocaleString(locales, options);
}

function toString(record, options) {
  return requireTimeZoneId(options && options.timeZone), getNativeInstant(record).toString(options);
}

function toBasicString(record) {
  return getNativeInstant(record).toString();
}

const toTemporal = getNativeInstant;

function addHours(record, hours) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    hours: hours
  }));
}

function addMinutes(record, minutes) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    minutes: minutes
  }));
}

function addSeconds(record, seconds) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    seconds: seconds
  }));
}

function addMilliseconds(record, milliseconds) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    milliseconds: milliseconds
  }));
}

function addMicroseconds(record, microseconds) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    microseconds: microseconds
  }));
}

function addNanoseconds(record, nanoseconds) {
  return createNativeInstantRecord(getNativeInstant(record).add({
    nanoseconds: nanoseconds
  }));
}

function subtractHours(record, hours) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    hours: hours
  }));
}

function subtractMinutes(record, minutes) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    minutes: minutes
  }));
}

function subtractSeconds(record, seconds) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    seconds: seconds
  }));
}

function subtractMilliseconds(record, milliseconds) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    milliseconds: milliseconds
  }));
}

function subtractMicroseconds(record, microseconds) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    microseconds: microseconds
  }));
}

function subtractNanoseconds(record, nanoseconds) {
  return createNativeInstantRecord(getNativeInstant(record).subtract({
    nanoseconds: nanoseconds
  }));
}

function roundToUnit(smallestUnit, record, options) {
  return ((record, options) => createNativeInstantRecord(getNativeInstant(record).round(options)))(record, createRoundToOptions(smallestUnit, options));
}

const roundToHour = /*@__PURE__*/ bindArgs(roundToUnit, "hour");

const roundToMinute = /*@__PURE__*/ bindArgs(roundToUnit, "minute");

const roundToSecond = /*@__PURE__*/ bindArgs(roundToUnit, "second");

const roundToMillisecond = /*@__PURE__*/ bindArgs(roundToUnit, "millisecond");

const roundToMicrosecond = /*@__PURE__*/ bindArgs(roundToUnit, "microsecond");

function diffHours(record0, record1, options) {
  return TemporalUtils.diffHours(getNativeInstant(record0), getNativeInstant(record1), options);
}

function diffMinutes(record0, record1, options) {
  return TemporalUtils.diffMinutes(getNativeInstant(record0), getNativeInstant(record1), options);
}

function diffSeconds(record0, record1, options) {
  return TemporalUtils.diffSeconds(getNativeInstant(record0), getNativeInstant(record1), options);
}

function diffMilliseconds(record0, record1, options) {
  return TemporalUtils.diffMilliseconds(getNativeInstant(record0), getNativeInstant(record1), options);
}

function diffMicroseconds(record0, record1, options) {
  return TemporalUtils.diffMicroseconds(getNativeInstant(record0), getNativeInstant(record1), options);
}

function diffNanoseconds(record0, record1, options) {
  return TemporalUtils.diffNanoseconds(getNativeInstant(record0), getNativeInstant(record1), options);
}

function timeZoneId() {
  return NativeTemporal.Now.timeZoneId();
}

function instant() {
  return createNativeInstantRecord(NativeTemporal.Now.instant());
}

function zonedDateTimeISO(timeZoneId) {
  return createNativeZonedDateTimeRecord(NativeTemporal.Now.zonedDateTimeISO(requireTimeZoneId(timeZoneId)));
}

function plainDateTimeISO(timeZoneId) {
  return createNativePlainDateTimeRecord(NativeTemporal.Now.plainDateTimeISO(requireTimeZoneId(timeZoneId)));
}

function plainDateISO(timeZoneId) {
  return createNativePlainDateRecord(NativeTemporal.Now.plainDateISO(requireTimeZoneId(timeZoneId)));
}

function plainTimeISO(timeZoneId) {
  return createNativePlainTimeRecord(NativeTemporal.Now.plainTimeISO(requireTimeZoneId(timeZoneId)));
}

export { abs, add, add$1, add$4 as add$2, add$2 as add$3, add$5 as add$4, add$3 as add$5, add$6, addDays, addDays$2 as addDays$1, addDays$1 as addDays$2, addHours, addHours$1, addHours$2, addHours$3, addMicroseconds, addMicroseconds$1, addMicroseconds$2, addMicroseconds$3, addMilliseconds, addMilliseconds$1, addMilliseconds$2, addMilliseconds$3, addMinutes, addMinutes$1, addMinutes$2, addMinutes$3, addMonths, addMonths$3 as addMonths$1, addMonths$1 as addMonths$2, addMonths$2 as addMonths$3, addNanoseconds, addNanoseconds$1, addNanoseconds$2, addNanoseconds$3, addSeconds, addSeconds$1, addSeconds$2, addSeconds$3, addWeeks, addWeeks$2 as addWeeks$1, addWeeks$1 as addWeeks$2, addYears, addYears$3 as addYears$1, addYears$1 as addYears$2, addYears$2 as addYears$3, blank, compare, compare$1, compare$4 as compare$2, compare$2 as compare$3, compare$5 as compare$4, compare$3 as compare$5, compare$6, create, create$1, create$5 as create$2, create$2 as create$3, create$6 as create$4, create$3 as create$5, create$4 as create$6, create$7, createFormat, createFormat$4 as createFormat$1, createFormat$1 as createFormat$2, createFormat$5 as createFormat$3, createFormat$2 as createFormat$4, createFormat$3 as createFormat$5, dayOfWeek, dayOfWeek$2 as dayOfWeek$1, dayOfWeek$1 as dayOfWeek$2, dayOfYear, dayOfYear$2 as dayOfYear$1, dayOfYear$1 as dayOfYear$2, daysInMonth, daysInMonth$3 as daysInMonth$1, daysInMonth$1 as daysInMonth$2, daysInMonth$2 as daysInMonth$3, daysInWeek, daysInWeek$2 as daysInWeek$1, daysInWeek$1 as daysInWeek$2, daysInYear, daysInYear$3 as daysInYear$1, daysInYear$1 as daysInYear$2, daysInYear$2 as daysInYear$3, diff, diff$1, diff$4 as diff$2, diff$2 as diff$3, diff$5 as diff$4, diff$3 as diff$5, diffDays, diffDays$2 as diffDays$1, diffDays$1 as diffDays$2, diffHours, diffHours$1, diffHours$2, diffHours$3, diffMicroseconds, diffMicroseconds$1, diffMicroseconds$2, diffMicroseconds$3, diffMilliseconds, diffMilliseconds$1, diffMilliseconds$2, diffMilliseconds$3, diffMinutes, diffMinutes$1, diffMinutes$2, diffMinutes$3, diffMonths, diffMonths$3 as diffMonths$1, diffMonths$1 as diffMonths$2, diffMonths$2 as diffMonths$3, diffNanoseconds, diffNanoseconds$1, diffNanoseconds$2, diffNanoseconds$3, diffSeconds, diffSeconds$1, diffSeconds$2, diffSeconds$3, diffWeeks, diffWeeks$2 as diffWeeks$1, diffWeeks$1 as diffWeeks$2, diffYears, diffYears$3 as diffYears$1, diffYears$1 as diffYears$2, diffYears$2 as diffYears$3, endOfDay, endOfDay$1, endOfHour, endOfHour$1, endOfHour$2, endOfMicrosecond, endOfMicrosecond$1, endOfMicrosecond$2, endOfMillisecond, endOfMillisecond$1, endOfMillisecond$2, endOfMinute, endOfMinute$1, endOfMinute$2, endOfMonth, endOfMonth$2 as endOfMonth$1, endOfMonth$1 as endOfMonth$2, endOfSecond, endOfSecond$1, endOfSecond$2, endOfWeek, endOfWeek$2 as endOfWeek$1, endOfWeek$1 as endOfWeek$2, endOfYear, endOfYear$3 as endOfYear$1, endOfYear$1 as endOfYear$2, endOfYear$2 as endOfYear$3, equals, equals$1, equals$5 as equals$2, equals$2 as equals$3, equals$6 as equals$4, equals$3 as equals$5, equals$4 as equals$6, fromEpochMilliseconds, fromEpochNanoseconds, fromFields, fromFields$4 as fromFields$1, fromFields$1 as fromFields$2, fromFields$5 as fromFields$3, fromFields$2 as fromFields$4, fromFields$3 as fromFields$5, fromFields$6, fromString, fromString$1, fromString$5 as fromString$2, fromString$2 as fromString$3, fromString$6 as fromString$4, fromString$3 as fromString$5, fromString$4 as fromString$6, fromString$7, getTimeZoneTransition, hoursInDay, inLeapYear, inLeapYear$3 as inLeapYear$1, inLeapYear$1 as inLeapYear$2, inLeapYear$2 as inLeapYear$3, instant, monthsInYear, monthsInYear$3 as monthsInYear$1, monthsInYear$1 as monthsInYear$2, monthsInYear$2 as monthsInYear$3, negated, offset, offsetNanoseconds, plainDateISO, plainDateTimeISO, plainTimeISO, round$4 as round, roundToDay, roundToDay$1, roundToHour, roundToHour$1, roundToHour$2, roundToHour$3, roundToMicrosecond, roundToMicrosecond$1, roundToMicrosecond$2, roundToMicrosecond$3, roundToMillisecond, roundToMillisecond$1, roundToMillisecond$2, roundToMillisecond$3, roundToMinute, roundToMinute$1, roundToMinute$2, roundToMinute$3, roundToMonth, roundToMonth$2 as roundToMonth$1, roundToMonth$1 as roundToMonth$2, roundToSecond, roundToSecond$1, roundToSecond$2, roundToSecond$3, roundToWeek, roundToWeek$2 as roundToWeek$1, roundToWeek$1 as roundToWeek$2, roundToYear, roundToYear$3 as roundToYear$1, roundToYear$1 as roundToYear$2, roundToYear$2 as roundToYear$3, sign, startOfDay, startOfDay$1, startOfHour, startOfHour$1, startOfHour$2, startOfMicrosecond, startOfMicrosecond$1, startOfMicrosecond$2, startOfMillisecond, startOfMillisecond$1, startOfMillisecond$2, startOfMinute, startOfMinute$1, startOfMinute$2, startOfMonth, startOfMonth$2 as startOfMonth$1, startOfMonth$1 as startOfMonth$2, startOfSecond, startOfSecond$1, startOfSecond$2, startOfWeek, startOfWeek$2 as startOfWeek$1, startOfWeek$1 as startOfWeek$2, startOfYear, startOfYear$3 as startOfYear$1, startOfYear$1 as startOfYear$2, startOfYear$2 as startOfYear$3, subtract, subtract$1, subtract$4 as subtract$2, subtract$2 as subtract$3, subtract$5 as subtract$4, subtract$3 as subtract$5, subtract$6, subtractDays, subtractDays$2 as subtractDays$1, subtractDays$1 as subtractDays$2, subtractHours, subtractHours$1, subtractHours$2, subtractHours$3, subtractMicroseconds, subtractMicroseconds$1, subtractMicroseconds$2, subtractMicroseconds$3, subtractMilliseconds, subtractMilliseconds$1, subtractMilliseconds$2, subtractMilliseconds$3, subtractMinutes, subtractMinutes$1, subtractMinutes$2, subtractMinutes$3, subtractMonths, subtractMonths$3 as subtractMonths$1, subtractMonths$1 as subtractMonths$2, subtractMonths$2 as subtractMonths$3, subtractNanoseconds, subtractNanoseconds$1, subtractNanoseconds$2, subtractNanoseconds$3, subtractSeconds, subtractSeconds$1, subtractSeconds$2, subtractSeconds$3, subtractWeeks, subtractWeeks$2 as subtractWeeks$1, subtractWeeks$1 as subtractWeeks$2, subtractYears, subtractYears$3 as subtractYears$1, subtractYears$1 as subtractYears$2, subtractYears$2 as subtractYears$3, timeZoneId, toBasicString, toBasicString$1, toBasicString$5 as toBasicString$2, toBasicString$2 as toBasicString$3, toBasicString$6 as toBasicString$4, toBasicString$3 as toBasicString$5, toBasicString$4 as toBasicString$6, toBasicString$7, toInstant, toLocaleString, toLocaleString$1, toLocaleString$5 as toLocaleString$2, toLocaleString$2 as toLocaleString$3, toLocaleString$6 as toLocaleString$4, toLocaleString$3 as toLocaleString$5, toLocaleString$4 as toLocaleString$6, toLocaleString$7, toPlainDate, toPlainDate$3 as toPlainDate$1, toPlainDate$1 as toPlainDate$2, toPlainDate$2 as toPlainDate$3, toPlainDateTime, toPlainDateTime$1, toPlainMonthDay, toPlainTime, toPlainTime$1, toPlainYearMonth, toString, toString$1, toString$5 as toString$2, toString$2 as toString$3, toString$6 as toString$4, toString$3 as toString$5, toString$4 as toString$6, toString$7, toTemporal, toTemporal$1, toTemporal$5 as toTemporal$2, toTemporal$2 as toTemporal$3, toTemporal$6 as toTemporal$4, toTemporal$3 as toTemporal$5, toTemporal$4 as toTemporal$6, toTemporal$7, toZonedDateTime$1 as toZonedDateTime, toZonedDateTime as toZonedDateTime$1, toZonedDateTimeISO, total, weekOfYear, weekOfYear$2 as weekOfYear$1, weekOfYear$1 as weekOfYear$2, withCalendar, withCalendar$2 as withCalendar$1, withCalendar$1 as withCalendar$2, withDayOfMonth, withDayOfMonth$2 as withDayOfMonth$1, withDayOfMonth$1 as withDayOfMonth$2, withDayOfWeek, withDayOfWeek$2 as withDayOfWeek$1, withDayOfWeek$1 as withDayOfWeek$2, withDayOfYear, withDayOfYear$2 as withDayOfYear$1, withDayOfYear$1 as withDayOfYear$2, withFields, withFields$4 as withFields$1, withFields$1 as withFields$2, withFields$5 as withFields$3, withFields$2 as withFields$4, withFields$3 as withFields$5, withFields$6, withPlainTime, withPlainTime$1, withTimeZone, withWeekOfYear, withWeekOfYear$2 as withWeekOfYear$1, withWeekOfYear$1 as withWeekOfYear$2, yearOfWeek, yearOfWeek$2 as yearOfWeek$1, yearOfWeek$1 as yearOfWeek$2, zonedDateTimeISO };
