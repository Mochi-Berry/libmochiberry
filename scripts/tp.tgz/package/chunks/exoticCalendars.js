import { eraYearToYear, constrainToRange, modFloor, epochDaysToIsoDate, isoPartsToEpochDays, computeIsoInLeapYear, bindArgs, milliInUtcDay, gregoryEraOrigins, isoDateToEpochDays, computeGregoryEraFields, memoize, throwRangeError, invalidCalendar } from "./internal.js";

import { createGregoryAlignedCalendar, createIntlScrapedCalendar, createArithmeticCalendar, unixEpochJulianDay, createIntlScrapedCalendarData, computeIntlDaysInMonth, computeIntlDaysInYear, computeIntlEpochMilli } from "./exoticCalendars-utils.js";

const buddhistEraOrigins = {
  "be": 0
};

const commonScrapedCalendarConfig = {
  l: 13,
  U: {
    1: 0,
    2: 29,
    8: 29,
    9: 29,
    10: 29,
    11: 29,
    12: 0
  },
  R: 30,
  ye(monthCodeNumber, isLeapMonth, day) {
    if (isLeapMonth) {
      switch (monthCodeNumber) {
       case 1:
        return 1651;

       case 2:
        return day < 30 ? 1947 : 1765;

       case 3:
        return day < 30 ? 1966 : 1955;

       case 4:
        return day < 30 ? 1963 : 1944;

       case 5:
        return day < 30 ? 1971 : 1952;

       case 6:
        return day < 30 ? 1960 : 1941;

       case 7:
        return day < 30 ? 1968 : 1938;

       case 8:
        return day < 30 ? 1957 : 1718;

       case 9:
        return 2014;

       case 10:
        return 1984;

       case 11:
        return day < 29 ? 2033 : 2034;

       case 12:
        return 1890;
      }
    }
    return 1972;
  }
};

function createChineseDangiCalendar(canonicalId) {
  return createIntlScrapedCalendar(canonicalId, commonScrapedCalendarConfig);
}

const copticEraOrigins = {
  "am": 0
};

const ethiopicEraOrigins = {
  "am": 0,
  "aa": 0
};

const ethioaaEraOrigins = {
  "aa": 0
};

function createCopticFamilyCalendar(epoch, eraOrigins, ameteAlemYearDelta = 0, hasAmeteMihretEra = 0) {
  return createArithmeticCalendar({
    k: eraOrigins,
    _(eraYear, normalizedEra, eraOrigin) {
      return "aa" === normalizedEra && hasAmeteMihretEra ? eraYear - 5500 : eraYearToYear(eraYear, eraOrigin);
    },
    ge(monthCodeNumber, isLeapMonth, day) {
      return constrainToRange(day, 1, isLeapMonth || 13 !== monthCodeNumber ? 30 : 6);
    },
    G(julianDay) {
      const [year, month, day] = ((epoch, julianDay) => {
        const year = Math.floor((4 * (julianDay - epoch) + 3) / 1461);
        const month = 1 + Math.floor((julianDay - copticFamilyToJulianDay(epoch, year, 1, 1)) / 30);
        return [ year, month, julianDay + 1 - copticFamilyToJulianDay(epoch, year, month, 1) ];
      })(epoch, julianDay);
      return {
        year: year + ameteAlemYearDelta,
        month: month,
        day: day
      };
    },
    K(year, month, day) {
      return copticFamilyToJulianDay(epoch, year - ameteAlemYearDelta, month, day);
    },
    o(year, month) {
      return ((year, month) => month % 13 != 0 ? 30 : copticFamilyLeapDay(year) + 5)(year - ameteAlemYearDelta, month);
    },
    i(year) {
      return 365 + copticFamilyLeapDay(year - ameteAlemYearDelta);
    },
    j() {
      return 13;
    },
    q(year) {
      return this.i(year) > 365;
    },
    h({year: year}) {
      return ameteAlemYearDelta ? {
        era: "aa",
        eraYear: year
      } : hasAmeteMihretEra && year <= 0 ? {
        era: "aa",
        eraYear: year + 5500
      } : {
        era: "am",
        eraYear: year
      };
    }
  });
}

function copticFamilyToJulianDay(epoch, year, month, day) {
  return epoch + 365 * year + Math.floor(year / 4) + 30 * (month - 1) + day - 1;
}

function copticFamilyLeapDay(year) {
  return Math.floor(modFloor(year, 4) / 3);
}

const hebrewEraOrigins = {
  "am": 0
};

function hebrewIsLeapYear(year) {
  return modFloor(7 * year + 1, 19) < 7;
}

function hebrewDelay1(year) {
  const months = Math.floor((235 * year - 234) / 19);
  let day = 29 * months + Math.floor((12084 + 13753 * months) / 25920);
  return modFloor(3 * (day + 1), 7) < 3 && (day += 1), day;
}

function hebrewStartOfYear(year) {
  return hebrewDelay1(year) + (year => {
    const last = hebrewDelay1(year - 1);
    const present = hebrewDelay1(year);
    return hebrewDelay1(year + 1) - present === 356 ? 2 : present - last === 382 ? 1 : 0;
  })(year);
}

function hebrewDaysInYear(year) {
  return hebrewStartOfYear(year + 1) - hebrewStartOfYear(year);
}

function hebrewDaysInMonth(year, month) {
  const normalizedMonth = month >= 6 && !hebrewIsLeapYear(year) ? month + 1 : month;
  if (4 === normalizedMonth || 7 === normalizedMonth || 9 === normalizedMonth || 11 === normalizedMonth || 13 === normalizedMonth) {
    return 29;
  }
  const yearType = (year => {
    let yearLength = hebrewDaysInYear(year);
    return yearLength > 380 && (yearLength -= 30), 353 === yearLength ? 0 : 354 === yearLength ? 1 : 2;
  })(year);
  return 2 === normalizedMonth ? 2 === yearType ? 30 : 29 : 3 === normalizedMonth ? 0 === yearType ? 29 : 30 : 6 === normalizedMonth ? hebrewIsLeapYear(year) ? 30 : 0 : 30;
}

const indianEraOrigins = {
  "shaka": 0
};

const umalquraPlainMonthDay30ReferenceYears = [ 1392, 1390, 1391, 1392, 1391, 1392, 1389, 1392, 1392, 1390, 1391, 1390 ];

function createIslamicCalendar(fromJulianDay, toJulianDay, intlUmalquraData) {
  return createArithmeticCalendar({
    k: {
      "bh": -1,
      "ah": 0
    },
    G: fromJulianDay,
    K: toJulianDay,
    o(year, month) {
      return intlUmalquraData && isUmalquraYear(year) ? computeIntlDaysInMonth(intlUmalquraData, year, month) : ((year, month) => 29 + month % 2 + (12 === month && islamicIsLeapYear(year) ? 1 : 0))(year, month);
    },
    i(year) {
      return intlUmalquraData && isUmalquraYear(year) ? computeIntlDaysInYear(intlUmalquraData, year) : islamicIsLeapYear(year) ? 355 : 354;
    },
    j() {
      return 12;
    },
    q(year) {
      return this.i(year) > 354;
    },
    u(monthCodeNumber, isLeapMonth, day) {
      const umalquraReferenceYear = intlUmalquraData && !isLeapMonth && 30 === day && umalquraPlainMonthDay30ReferenceYears[monthCodeNumber - 1];
      return intlUmalquraData && umalquraReferenceYear ? {
        year: umalquraReferenceYear,
        month: monthCodeNumber
      } : void 0;
    },
    h({year: year}) {
      return year < 1 ? {
        era: "bh",
        eraYear: 1 - year
      } : {
        era: "ah",
        eraYear: year
      };
    }
  });
}

function islamicToJulianDay(epoch, year, month, day) {
  return day + Math.ceil(29.5 * (month - 1)) + 354 * (year - 1) + Math.floor((3 + 11 * year) / 30) + epoch - 1;
}

function julianDayToIslamic(epoch, julianDay) {
  const year = Math.floor((30 * (julianDay - epoch) + 10646) / 10631);
  const month = Math.min(12, Math.ceil((julianDay - (29 + islamicToJulianDay(epoch, year, 1, 1))) / 29.5) + 1);
  return {
    year: year,
    month: month,
    day: julianDay - islamicToJulianDay(epoch, year, month, 1) + 1
  };
}

function islamicIsLeapYear(year) {
  return modFloor(14 + 11 * year, 30) < 11;
}

function isUmalquraYear(year) {
  return year >= 1300 && year <= 1600;
}

function julianDayToUmalqura(intlUmalquraData, julianDay) {
  const days = julianDay - 1948440;
  if (days < 460322 || days >= 566987) {
    return julianDayToIslamic(1948440, julianDay);
  }
  const {year: year, month: month, day: day} = intlUmalquraData.ke(epochDaysToIsoDate(julianDay - unixEpochJulianDay));
  return {
    year: year,
    month: month,
    day: day
  };
}

function umalquraToJulianDay(intlUmalquraData, year, month, day) {
  return isUmalquraYear(year) ? computeIntlEpochMilli(intlUmalquraData, year, month, day) / milliInUtcDay + unixEpochJulianDay : islamicToJulianDay(1948440, year, month, day);
}

const japaneseEraOrigins = /*@__PURE__*/ Object.assign({}, gregoryEraOrigins, {
  "meiji": 1867,
  "taisho": 1911,
  "showa": 1925,
  "heisei": 1988,
  "reiwa": 2018
});

function computeJapaneseEraFields(isoDate) {
  const epochDays = isoDateToEpochDays(isoDate);
  const era = epochDays >= 18017 ? "reiwa" : epochDays >= 6947 ? "heisei" : epochDays >= -15713 ? "showa" : epochDays >= -20974 ? "taisho" : epochDays >= -35428 ? "meiji" : void 0;
  return era ? {
    era: era,
    eraYear: isoDate.year - japaneseEraOrigins[era]
  } : computeGregoryEraFields(isoDate);
}

const persianEraOrigins = {
  "ap": 0
};

const persianMonthStarts = [ 0, 31, 62, 93, 124, 155, 186, 216, 246, 276, 306, 336 ];

function persianIsLeapYear(year) {
  return modFloor(25 * year + 11, 33) < 8;
}

const rocEraOrigins = {
  "broc": -1,
  "roc": 0
};

const buddhistMeta = [ "buddhist", () => createGregoryAlignedCalendar({
  se: 543,
  k: buddhistEraOrigins,
  h(_isoDate, calendarYear) {
    return {
      era: "be",
      eraYear: calendarYear
    };
  }
}) ];

const chineseMeta = [ "chinese", createChineseDangiCalendar ];

const copticMeta = [ "coptic", () => createCopticFamilyCalendar(1824665, copticEraOrigins) ];

const dangiMeta = [ "dangi", createChineseDangiCalendar ];

const ethiopicMeta = [ "ethiopic", () => createCopticFamilyCalendar(1723856, ethiopicEraOrigins, 0, 1) ];

const ethiopicAmeteAlemMeta = [ "ethioaa", () => createCopticFamilyCalendar(1723856, ethioaaEraOrigins, 5500) ];

const hebrewMeta = [ "hebrew", () => createArithmeticCalendar({
  k: hebrewEraOrigins,
  l: -6,
  G(julianDay) {
    const day = julianDay - 347997;
    let year = Math.floor((25920 * day / 765433 * 19 + 234) / 235) + 1;
    let yearStart = hebrewStartOfYear(year);
    let dayOfYear = Math.floor(day - yearStart);
    for (;dayOfYear < 1; ) {
      year--, yearStart = hebrewStartOfYear(year), dayOfYear = Math.floor(day - yearStart);
    }
    let month = 1;
    let monthStart = 0;
    for (;monthStart < dayOfYear; ) {
      monthStart += hebrewDaysInMonth(year, month), month++;
    }
    return month--, monthStart -= hebrewDaysInMonth(year, month), {
      year: year,
      month: month,
      day: dayOfYear - monthStart
    };
  },
  K(year, month, day) {
    let julianDay = hebrewStartOfYear(year);
    for (let i = 1; i < month; i++) {
      julianDay += hebrewDaysInMonth(year, i);
    }
    return julianDay + day + 347997;
  },
  o: hebrewDaysInMonth,
  i: hebrewDaysInYear,
  j(year) {
    return hebrewIsLeapYear(year) ? 13 : 12;
  },
  q: hebrewIsLeapYear,
  p(year) {
    return hebrewIsLeapYear(year) ? 6 : void 0;
  },
  L(year, month) {
    return hebrewIsLeapYear(year) && 6 === month ? [ 5, 1 ] : [ month - (hebrewIsLeapYear(year) && month > 6 ? 1 : 0), 0 ];
  },
  u(monthCodeNumber, isLeapMonth, day) {
    return isLeapMonth && 5 === monthCodeNumber && day <= 30 ? {
      year: 5730,
      month: 6
    } : void 0;
  },
  h({year: year}) {
    return {
      era: "am",
      eraYear: year
    };
  }
}) ];

const indianMeta = [ "indian", function() {
  return createArithmeticCalendar({
    k: indianEraOrigins,
    G(julianDay) {
      const gregory = epochDaysToIsoDate(julianDay - unixEpochJulianDay);
      let year = gregory.year - 78;
      let dayOfGregorianYear = julianDay - (isoPartsToEpochDays(gregory.year, 1, 1) + unixEpochJulianDay);
      let firstMonthDays;
      if (dayOfGregorianYear < 80 ? (year--, firstMonthDays = computeIsoInLeapYear(gregory.year - 1) ? 31 : 30, 
      dayOfGregorianYear += firstMonthDays + 155 + 90 + 10) : (firstMonthDays = computeIsoInLeapYear(gregory.year) ? 31 : 30, 
      dayOfGregorianYear -= 80), dayOfGregorianYear < firstMonthDays) {
        return {
          year: year,
          month: 1,
          day: dayOfGregorianYear + 1
        };
      }
      let monthDay = dayOfGregorianYear - firstMonthDays;
      return monthDay < 155 ? {
        year: year,
        month: Math.floor(monthDay / 31) + 2,
        day: monthDay % 31 + 1
      } : (monthDay -= 155, {
        year: year,
        month: Math.floor(monthDay / 30) + 7,
        day: monthDay % 30 + 1
      });
    },
    K(year, month, day) {
      const gregoryYear = year + 78;
      let firstMonthDays;
      let julianDay;
      return computeIsoInLeapYear(gregoryYear) ? (firstMonthDays = 31, julianDay = isoPartsToEpochDays(gregoryYear, 3, 21) + unixEpochJulianDay) : (firstMonthDays = 30, 
      julianDay = isoPartsToEpochDays(gregoryYear, 3, 22) + unixEpochJulianDay), 1 === month || (julianDay += firstMonthDays + 31 * Math.min(month - 2, 5), 
      month >= 8 && (julianDay += 30 * (month - 7))), julianDay + day - 1;
    },
    o(year, month) {
      return 1 === month && computeIsoInLeapYear(year + 78) || month >= 2 && month <= 6 ? 31 : 30;
    },
    i(year) {
      return computeIsoInLeapYear(year + 78) ? 366 : 365;
    },
    j() {
      return 12;
    },
    q(year) {
      return this.i(year) > 365;
    },
    h({year: year}) {
      return {
        era: "shaka",
        eraYear: year
      };
    }
  });
} ];

const japaneseMeta = [ "japanese", () => createGregoryAlignedCalendar({
  k: japaneseEraOrigins,
  je: 1,
  h: computeJapaneseEraFields
}) ];

const islamicCivilMeta = [ "islamic-civil", () => createIslamicCalendar(bindArgs(julianDayToIslamic, 1948440), bindArgs(islamicToJulianDay, 1948440)) ];

const islamicTabularMeta = [ "islamic-tbla", () => createIslamicCalendar(bindArgs(julianDayToIslamic, 1948439), bindArgs(islamicToJulianDay, 1948439)) ];

const islamicUmmAlQuraMeta = [ "islamic-umalqura", canonicalId => {
  const intlUmalquraData = createIntlScrapedCalendarData(canonicalId);
  return createIslamicCalendar(bindArgs(julianDayToUmalqura, intlUmalquraData), bindArgs(umalquraToJulianDay, intlUmalquraData), intlUmalquraData);
} ];

const persianMeta = [ "persian", () => createArithmeticCalendar({
  k: persianEraOrigins,
  G(julianDay) {
    const daysSinceEpoch = julianDay - 1948320;
    const year = 1 + Math.floor((33 * daysSinceEpoch + 3) / 12053);
    const dayOfYear = daysSinceEpoch - (365 * (year - 1) + Math.floor((8 * year + 21) / 33));
    const month = Math.floor(dayOfYear < 216 ? dayOfYear / 31 : (dayOfYear - 6) / 30);
    return {
      year: year,
      month: month + 1,
      day: dayOfYear - persianMonthStarts[month] + 1
    };
  },
  K(year, month, day) {
    return 1948319 + 365 * (year - 1) + Math.floor((8 * year + 21) / 33) + persianMonthStarts[month - 1] + day;
  },
  o(year, month) {
    return month <= 6 ? 31 : month <= 11 || persianIsLeapYear(year) ? 30 : 29;
  },
  i(year) {
    return persianIsLeapYear(year) ? 366 : 365;
  },
  j() {
    return 12;
  },
  q: persianIsLeapYear,
  h({year: year}) {
    return {
      era: "ap",
      eraYear: year
    };
  }
}) ];

const rocMeta = [ "roc", () => createGregoryAlignedCalendar({
  se: -1911,
  k: rocEraOrigins,
  h(_isoDate, calendarYear) {
    return calendarYear < 1 ? {
      era: "broc",
      eraYear: 1 - calendarYear
    } : {
      era: "roc",
      eraYear: calendarYear
    };
  }
}) ];

const exoticCreatorMap = /*@__PURE__*/ new Map([ buddhistMeta, chineseMeta, copticMeta, dangiMeta, ethiopicMeta, ethiopicAmeteAlemMeta, hebrewMeta, indianMeta, japaneseMeta, islamicCivilMeta, islamicTabularMeta, islamicUmmAlQuraMeta, persianMeta, rocMeta ]);

const forbiddenExoticCalendarIdMap = {
  "islamic": 1,
  "islamic-rgsa": 1
};

const deprecatedExoticCalendarIdMap = {
  "ethiopic-amete-alem": "ethioaa",
  "islamicc": "islamic-civil"
};

const getOrCreateExoticCalendar = /*@__PURE__*/ memoize((canonicalId, createExoticCalendar) => {
  const calendar = createExoticCalendar(canonicalId);
  return calendar.id = canonicalId, calendar;
});

function createExoticCalendarGetter(meta) {
  return () => getOrCreateExoticCalendar(...meta);
}

function getExoticCalendarById(lowerRawCalendarId) {
  const meta = queryExoticCalendarMeta(lowerRawCalendarId);
  return meta || throwRangeError(invalidCalendar(lowerRawCalendarId)), getOrCreateExoticCalendar(...meta);
}

function queryExoticCalendarMeta(lowerRawCalendarId) {
  forbiddenExoticCalendarIdMap[lowerRawCalendarId] && throwRangeError(invalidCalendar(lowerRawCalendarId));
  const normCalendarId = deprecatedExoticCalendarIdMap[lowerRawCalendarId] || lowerRawCalendarId;
  const createCalendar = exoticCreatorMap.get(normCalendarId);
  return createCalendar && [ normCalendarId, createCalendar ];
}

export { buddhistMeta, chineseMeta, copticMeta, createExoticCalendarGetter, dangiMeta, ethiopicAmeteAlemMeta, ethiopicMeta, getExoticCalendarById, hebrewMeta, indianMeta, islamicCivilMeta, islamicTabularMeta, islamicUmmAlQuraMeta, japaneseMeta, persianMeta, queryExoticCalendarMeta, rocMeta };
