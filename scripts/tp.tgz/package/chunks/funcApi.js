import { PlainYearMonthBranding, PlainMonthDayBranding, PlainDateBranding, PlainDateTimeBranding, PlainTimeBranding, ZonedDateTimeBranding, InstantBranding, DurationBranding, CalendarBranding, invalidRecordType, defineTemporalClass, attachDebugString } from "./apiHelpers.js";

import { throwTypeError, invalidBag, throwRangeError, exoticCalendarRequired } from "./internal.js";

const PlainYearMonthRecordBranding = `${PlainYearMonthBranding}Record`;

const PlainMonthDayRecordBranding = `${PlainMonthDayBranding}Record`;

const PlainDateRecordBranding = `${PlainDateBranding}Record`;

const PlainDateTimeRecordBranding = `${PlainDateTimeBranding}Record`;

const PlainTimeRecordBranding = `${PlainTimeBranding}Record`;

const ZonedDateTimeRecordBranding = `${ZonedDateTimeBranding}Record`;

const InstantRecordBranding = `${InstantBranding}Record`;

const DurationRecordBranding = `${DurationBranding}Record`;

const CalendarRecordBranding = `${CalendarBranding}Record`;

const calendarMap = /*@__PURE__*/ new WeakMap;

const instantMap = /*@__PURE__*/ new WeakMap;

const zonedDateTimeMap = /*@__PURE__*/ new WeakMap;

const plainDateTimeMap = /*@__PURE__*/ new WeakMap;

const plainDateMap = /*@__PURE__*/ new WeakMap;

const plainTimeMap = /*@__PURE__*/ new WeakMap;

const plainYearMonthMap = /*@__PURE__*/ new WeakMap;

const plainMonthDayMap = /*@__PURE__*/ new WeakMap;

const durationMap = /*@__PURE__*/ new WeakMap;

function getCalendarSlots(record) {
  return getCalendarSlotsIfPresent(record) || invalidRecordType();
}

function getCalendarSlotsIfPresent(record) {
  return calendarMap.get(record);
}

function isInstantRecord(record) {
  return !!getInstantSlotsIfPresent(record);
}

function getInstantSlots(record) {
  return getInstantSlotsIfPresent(record) || invalidRecordType();
}

function getInstantSlotsIfPresent(record) {
  return instantMap.get(record);
}

function setInstantSlots(instance, slots) {
  instantMap.set(instance, slots);
}

function isZonedDateTimeRecord(record) {
  return !!getZonedDateTimeSlotsIfPresent(record);
}

function getZonedDateTimeSlots(record) {
  return getZonedDateTimeSlotsIfPresent(record) || invalidRecordType();
}

function getZonedDateTimeSlotsIfPresent(record) {
  return zonedDateTimeMap.get(record);
}

function setZonedDateTimeSlots(instance, slots) {
  zonedDateTimeMap.set(instance, slots);
}

function isPlainDateTimeRecord(record) {
  return !!getPlainDateTimeSlotsIfPresent(record);
}

function getPlainDateTimeSlots(record) {
  return getPlainDateTimeSlotsIfPresent(record) || invalidRecordType();
}

function getPlainDateTimeSlotsIfPresent(record) {
  return plainDateTimeMap.get(record);
}

function setPlainDateTimeSlots(instance, slots) {
  plainDateTimeMap.set(instance, slots);
}

function isPlainDateRecord(record) {
  return !!getPlainDateSlotsIfPresent(record);
}

function getPlainDateSlots(record) {
  return getPlainDateSlotsIfPresent(record) || invalidRecordType();
}

function getPlainDateSlotsIfPresent(record) {
  return plainDateMap.get(record);
}

function setPlainDateSlots(instance, slots) {
  plainDateMap.set(instance, slots);
}

function isPlainTimeRecord(record) {
  return !!getPlainTimeSlotsIfPresent(record);
}

function getPlainTimeSlots(record) {
  return getPlainTimeSlotsIfPresent(record) || invalidRecordType();
}

function getPlainTimeSlotsIfPresent(record) {
  return plainTimeMap.get(record);
}

function setPlainTimeSlots(instance, slots) {
  plainTimeMap.set(instance, slots);
}

function isPlainYearMonthRecord(record) {
  return !!getPlainYearMonthSlotsIfPresent(record);
}

function getPlainYearMonthSlots(record) {
  return getPlainYearMonthSlotsIfPresent(record) || invalidRecordType();
}

function getPlainYearMonthSlotsIfPresent(record) {
  return plainYearMonthMap.get(record);
}

function setPlainYearMonthSlots(instance, slots) {
  plainYearMonthMap.set(instance, slots);
}

function isPlainMonthDayRecord(record) {
  return !!getPlainMonthDaySlotsIfPresent(record);
}

function getPlainMonthDaySlots(record) {
  return getPlainMonthDaySlotsIfPresent(record) || invalidRecordType();
}

function getPlainMonthDaySlotsIfPresent(record) {
  return plainMonthDayMap.get(record);
}

function setPlainMonthDaySlots(instance, slots) {
  plainMonthDayMap.set(instance, slots);
}

function isDurationRecord(record) {
  return !!getDurationSlotsIfPresent(record);
}

function getDurationSlots(record) {
  return getDurationSlotsIfPresent(record) || invalidRecordType();
}

function getDurationSlotsIfPresent(record) {
  return durationMap.get(record);
}

function setDurationSlots(instance, slots) {
  durationMap.set(instance, slots);
}

function validateBag(bag) {
  return ((record => !!getCalendarSlotsIfPresent(record))(record = bag) || isInstantRecord(record) || isZonedDateTimeRecord(record) || isPlainDateTimeRecord(record) || isPlainDateRecord(record) || isPlainTimeRecord(record) || isPlainYearMonthRecord(record) || isPlainMonthDayRecord(record) || isDurationRecord(record) || void 0 !== bag.calendar || void 0 !== bag.timeZone) && throwTypeError(invalidBag), 
  bag;
  var record;
}

const CalendarRecord = /*@__PURE__*/ defineTemporalClass(CalendarRecordBranding, class {
  toJSON() {
    return getCalendarRecordId(this);
  }
  valueOf() {
    return getCalendarRecordId(this);
  }
});

function createCalendarRecord(id, getImpl) {
  const instance = Object.create(CalendarRecord.prototype);
  return ((instance, slots) => {
    calendarMap.set(instance, slots);
  })(instance, {
    id: id,
    xe: getImpl
  }), attachDebugString(instance), instance;
}

function getCalendarRecordId(record) {
  return getCalendarSlots(record).id;
}

function getCalendarRecordImplCreator(record) {
  const getImpl = getCalendarSlots(record).xe;
  return getImpl || throwRangeError(exoticCalendarRequired(getCalendarRecordId(record), "getExotic or getAny")), 
  getImpl;
}

export { DurationRecordBranding, InstantRecordBranding, PlainDateRecordBranding, PlainDateTimeRecordBranding, PlainMonthDayRecordBranding, PlainTimeRecordBranding, PlainYearMonthRecordBranding, ZonedDateTimeRecordBranding, createCalendarRecord, getCalendarRecordId, getCalendarRecordImplCreator, getDurationSlots, getInstantSlots, getPlainDateSlots, getPlainDateSlotsIfPresent, getPlainDateTimeSlots, getPlainDateTimeSlotsIfPresent, getPlainMonthDaySlots, getPlainTimeSlots, getPlainTimeSlotsIfPresent, getPlainYearMonthSlots, getZonedDateTimeSlots, getZonedDateTimeSlotsIfPresent, isDurationRecord, isInstantRecord, isPlainDateRecord, isPlainDateTimeRecord, isPlainMonthDayRecord, isPlainTimeRecord, isPlainYearMonthRecord, isZonedDateTimeRecord, setDurationSlots, setInstantSlots, setPlainDateSlots, setPlainDateTimeSlots, setPlainMonthDaySlots, setPlainTimeSlots, setPlainYearMonthSlots, setZonedDateTimeSlots, validateBag };
