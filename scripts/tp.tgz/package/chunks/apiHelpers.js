import { createNameDescriptors, createStringTagDescriptors, mapProps, noop, throwTypeError, invalidCallingContext, forbiddenValueOf as forbiddenValueOf$1, computeCalendarEraFields, computeCalendarDateFields, computeCalendarMonthCode, computeCalendarDaysInMonth, computeCalendarDaysInYear, computeCalendarMonthsInYear, computeCalendarInLeapYear, computeIsoDayOfWeek, computeCalendarDayOfYear, computeCalendarWeekOfYear, computeCalendarYearOfWeek, refineDiffOptions, diffEpochNanosRounded, getCommonCalendar, diffZonedDateTimesRounded, diffDateTimesRounded, diffDatesRounded, diffYearMonthsRounded, diffTimesRounded, createDurationSlots, negateDurationFields, mergeDateFields, refineCalendarDateFields, refineOverflowOptions, createDateFromRefinedFields, mergeDateTimeFields, createDateTimeFromMergedFields, mergeYearMonthFields, createYearMonthFromRefinedFields, mergeMonthDayFields, refineMonthDayFields, createMonthDayFromRefinedFields, mergeTimeFields, resolveTimeFields, mergeZonedDateTimeFields, refineZonedFieldOptions, createZonedDateTimeFromMergedFields, createPropGetters, durationGetters as durationGetters$1, timeGetters as timeGetters$1, bindArgs, refineUnitDiffOptions, getCommonTimeZone, countRelativeUnit, diffZonedEpochsExact, createZonedRelativeOps, countZonedDayWeekUnit, createDateRelativeOps, diffDateTimesExact, countDateWeeks, countEpochNanoDays, timeFieldsToNano, isoDateTimeToEpochNano, isoDateToEpochNano, diffCalendarDates, countYearMonthUnit, countDateTimeUnit, countTimeUnit, countEpochNanoUnit, moveDateByCalendarUnits, toStrictInteger, moveToRefinedDayOfYear, moveToRefinedDayOfMonth, moveToRefinedDayOfWeek, moveToRefinedWeekOfYear } from "./internal.js";

import { toIntegerWithTrunc, toPositiveIntegerWithTruncation } from "temporal-utils/protected";

import "temporal-utils/protected-error-messages";

const PlainYearMonthBranding = "PlainYearMonth";

const PlainMonthDayBranding = "PlainMonthDay";

const PlainDateBranding = "PlainDate";

const PlainDateTimeBranding = "PlainDateTime";

const PlainTimeBranding = "PlainTime";

const ZonedDateTimeBranding = "ZonedDateTime";

const InstantBranding = "Instant";

const DurationBranding = "Duration";

const CalendarBranding = "Calendar";

function defineTemporalClass(branding, cls, getSlots, ...getterMaps) {
  return Object.defineProperties(cls, createNameDescriptors(branding)), Object.defineProperties(cls.prototype, createStringTagDescriptors("Temporal." + branding)), 
  Object.defineProperties(cls.prototype, mapProps(getter => ({
    get() {
      return getter(getSlots(this));
    },
    configurable: 1
  }), Object.assign({}, ...getterMaps))), cls;
}

const attachDebugString = "noop" !== noop.name || globalThis.process ? noop : instance => {
  Object.defineProperty(instance, "_str_", {
    value: instance.toJSON()
  });
};

function invalidRecordType() {
  throwTypeError(invalidCallingContext);
}

function forbiddenValueOf() {
  throwTypeError(forbiddenValueOf$1);
}

const yearMonthFieldGetters$1 = {
  era(slots) {
    return computeCalendarEraFields(slots.calendar, slots).era;
  },
  eraYear(slots) {
    return computeCalendarEraFields(slots.calendar, slots).eraYear;
  },
  year(slots) {
    return computeCalendarDateFields(slots.calendar, slots).year;
  },
  month(slots) {
    return computeCalendarDateFields(slots.calendar, slots).month;
  },
  monthCode(slots) {
    return computeCalendarMonthCode(slots.calendar, slots);
  }
};

const dateFieldGetters$1 = {
  era(slots) {
    return computeCalendarEraFields(slots.calendar, slots).era;
  },
  eraYear(slots) {
    return computeCalendarEraFields(slots.calendar, slots).eraYear;
  },
  year(slots) {
    return computeCalendarDateFields(slots.calendar, slots).year;
  },
  month(slots) {
    return computeCalendarDateFields(slots.calendar, slots).month;
  },
  monthCode(slots) {
    return computeCalendarMonthCode(slots.calendar, slots);
  },
  day(slots) {
    return computeCalendarDateFields(slots.calendar, slots).day;
  }
};

const monthDayFieldGetters$1 = {
  monthCode(slots) {
    return computeCalendarMonthCode(slots.calendar, slots);
  },
  day(slots) {
    return computeCalendarDateFields(slots.calendar, slots).day;
  }
};

const yearMonthDerivedGetters = {
  daysInMonth(slots) {
    return computeCalendarDaysInMonth(slots.calendar, slots);
  },
  daysInYear(slots) {
    return computeCalendarDaysInYear(slots.calendar, slots);
  },
  monthsInYear(slots) {
    return computeCalendarMonthsInYear(slots.calendar, slots);
  },
  inLeapYear(slots) {
    return computeCalendarInLeapYear(slots.calendar, slots);
  }
};

const dateDerivedGetters = {
  dayOfWeek(slots) {
    return computeIsoDayOfWeek(slots);
  },
  dayOfYear(slots) {
    return computeCalendarDayOfYear(slots.calendar, slots);
  },
  weekOfYear(slots) {
    return computeCalendarWeekOfYear(slots.calendar, slots);
  },
  yearOfWeek(slots) {
    return computeCalendarYearOfWeek(slots.calendar, slots);
  },
  daysInWeek() {
    return 7;
  },
  daysInMonth(slots) {
    return computeCalendarDaysInMonth(slots.calendar, slots);
  },
  daysInYear(slots) {
    return computeCalendarDaysInYear(slots.calendar, slots);
  },
  monthsInYear(slots) {
    return computeCalendarMonthsInYear(slots.calendar, slots);
  },
  inLeapYear(slots) {
    return computeCalendarInLeapYear(slots.calendar, slots);
  }
};

function diffInstants(invert, instantSlots0, instantSlots1, options) {
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 3, 5);
  return createDiffDurationSlots(invert, diffEpochNanosRounded(instantSlots0.epochNanoseconds, instantSlots1.epochNanoseconds, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function diffZonedDateTimes(invert, slots0, slots1, options) {
  const calendar = getCommonCalendar(slots0.calendar, slots1.calendar);
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 5);
  return createDiffDurationSlots(invert, diffZonedDateTimesRounded(calendar, slots0, slots1, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function diffDateTimes(invert, plainDateTimeSlots0, plainDateTimeSlots1, options) {
  const calendar = getCommonCalendar(plainDateTimeSlots0.calendar, plainDateTimeSlots1.calendar);
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 6);
  return createDiffDurationSlots(invert, diffDateTimesRounded(calendar, plainDateTimeSlots0, plainDateTimeSlots1, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function diffDates(invert, plainDateSlots0, plainDateSlots1, options) {
  const calendar = getCommonCalendar(plainDateSlots0.calendar, plainDateSlots1.calendar);
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 6, 9, 6);
  return createDiffDurationSlots(invert, diffDatesRounded(calendar, plainDateSlots0, plainDateSlots1, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function diffYearMonths(invert, plainYearMonthSlots0, plainYearMonthSlots1, options) {
  const calendar = getCommonCalendar(plainYearMonthSlots0.calendar, plainYearMonthSlots1.calendar);
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 9, 9, 8);
  return createDiffDurationSlots(invert, diffYearMonthsRounded(calendar, plainYearMonthSlots0, plainYearMonthSlots1, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function diffTimes(invert, plainTimeSlots0, plainTimeSlots1, options) {
  const [largestUnit, smallestUnit, roundingInc, roundingMode] = refineDiffOptions(invert, options, 5, 5);
  return createDiffDurationSlots(invert, diffTimesRounded(plainTimeSlots0, plainTimeSlots1, largestUnit, smallestUnit, roundingInc, roundingMode));
}

function createDiffDurationSlots(invert, durationFields) {
  return createDurationSlots(invert ? negateDurationFields(durationFields) : durationFields);
}

function withDateFields(slots, modFields, options) {
  const {calendar: calendar} = slots;
  const fields = mergeDateFields(calendar, slots, modFields);
  const [year, monthCodeParts] = refineCalendarDateFields(fields, calendar);
  const overflow = refineOverflowOptions(options);
  return createDateFromRefinedFields(fields, calendar, year, monthCodeParts, overflow);
}

function withDateTimeFields(slots, modFields, options) {
  const {calendar: calendar} = slots;
  const [mergedFields, calendarFields] = mergeDateTimeFields(calendar, slots, modFields);
  const [year, monthCodeParts] = refineCalendarDateFields(calendarFields, calendar);
  const overflow = refineOverflowOptions(options);
  return createDateTimeFromMergedFields(mergedFields, calendarFields, calendar, year, monthCodeParts, overflow);
}

function withYearMonthFields(slots, modFields, options) {
  const {calendar: calendar} = slots;
  const fields = mergeYearMonthFields(calendar, slots, modFields);
  const [year, monthCodeParts] = refineCalendarDateFields(fields, calendar, 1);
  const overflow = refineOverflowOptions(options);
  return createYearMonthFromRefinedFields(fields, calendar, year, monthCodeParts, overflow);
}

function withMonthDayFields(slots, modFields, options) {
  const {calendar: calendar} = slots;
  const fields = mergeMonthDayFields(calendar, slots, modFields);
  const [year, monthCodeParts] = refineMonthDayFields(fields, calendar);
  const overflow = refineOverflowOptions(options);
  return createMonthDayFromRefinedFields(fields, calendar, year, monthCodeParts, overflow);
}

function withTimeFields(slots, modFields, options) {
  const refinedFields = mergeTimeFields(slots, modFields);
  const overflow = refineOverflowOptions(options);
  return resolveTimeFields(refinedFields, overflow);
}

function withZonedDateTimeFields(slots, modFields, options) {
  const {calendar: calendar} = slots;
  const [mergedFields, calendarFields] = mergeZonedDateTimeFields(calendar, slots, modFields);
  const [year, monthCodeParts] = refineCalendarDateFields(calendarFields, calendar);
  const [overflow, offsetDisambig, epochDisambig] = refineZonedFieldOptions(options, 2);
  return createZonedDateTimeFromMergedFields(slots, mergedFields, calendarFields, year, monthCodeParts, overflow, offsetDisambig, epochDisambig);
}

function createNativeGetters(shimGetters) {
  return createPropGetters(Object.keys(shimGetters));
}

const durationGetters = /*@__PURE__*/ createNativeGetters(durationGetters$1);

const timeGetters = /*@__PURE__*/ createNativeGetters(timeGetters$1);

const yearMonthFieldGetters = /*@__PURE__*/ createNativeGetters(yearMonthFieldGetters$1);

const dateFieldGetters = /*@__PURE__*/ createNativeGetters(dateFieldGetters$1);

const monthDayFieldGetters = /*@__PURE__*/ createNativeGetters(monthDayFieldGetters$1);

const diffZonedYears = /*@__PURE__*/ bindArgs(diffZonedCalendarUnit, 9);

const diffZonedMonths = /*@__PURE__*/ bindArgs(diffZonedCalendarUnit, 8);

const diffZonedWeeks = /*@__PURE__*/ bindArgs(diffZonedDayWeekUnit, 7);

const diffZonedDays = /*@__PURE__*/ bindArgs(diffZonedDayWeekUnit, 6);

const diffInstantEpochNanoTimeUnit = diffInstantTimeUnit;

const diffDateYears = /*@__PURE__*/ bindArgs(diffDateCalendarUnit, 9);

const diffDateMonths = /*@__PURE__*/ bindArgs(diffDateCalendarUnit, 8);

const diffDateTimeYears = /*@__PURE__*/ bindArgs(diffDateTimeCalendarUnit, 9);

const diffDateTimeMonths = /*@__PURE__*/ bindArgs(diffDateTimeCalendarUnit, 8);

const diffYearMonthYears = /*@__PURE__*/ bindArgs(diffYearMonthUnit, 9);

const diffYearMonthMonths = /*@__PURE__*/ bindArgs(diffYearMonthUnit, 8);

function diffZonedEpochNanoTimeUnit(unit, slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), diffInstantTimeUnit(unit, slots0, slots1, options);
}

function diffDateTimeEpochNanoTimeUnit(unit, slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), countDateTimeUnit(slots0, slots1, unit, refineUnitDiffOptions(unit, options));
}

function diffTimeNanoOfDayTimeUnit(unit, slots0, slots1, options) {
  return countTimeUnit(slots0, slots1, unit, refineUnitDiffOptions(unit, options));
}

function adaptRecordTimeUnitDiff(diffSlots, getSlots) {
  return (unit, record0, record1, options) => diffSlots(unit, getSlots(record0), getSlots(record1), options);
}

function diffInstantTimeUnit(unit, slots0, slots1, options) {
  return countEpochNanoUnit(slots0.epochNanoseconds, slots1.epochNanoseconds, unit, refineUnitDiffOptions(unit, options));
}

function diffZonedCalendarUnit(unit, slots0, slots1, options) {
  const calendar = getCommonCalendar(slots0.calendar, slots1.calendar);
  const rounding = refineUnitDiffOptions(unit, options);
  const timeZone = getCommonTimeZone(slots0.timeZone, slots1.timeZone);
  return slots0.epochNanoseconds === slots1.epochNanoseconds ? 0 : countRelativeUnit(unit, {
    he: () => diffZonedEpochsExact(timeZone, calendar, slots0, slots1, unit),
    le: createZonedRelativeOps(calendar, timeZone, slots0),
    ie: slots1.epochNanoseconds
  }, rounding, 1);
}

function diffZonedDayWeekUnit(unit, slots0, slots1, options) {
  getCommonCalendar(slots0.calendar, slots1.calendar);
  const rounding = refineUnitDiffOptions(unit, options);
  const timeZone = getCommonTimeZone(slots0.timeZone, slots1.timeZone);
  return slots0.epochNanoseconds === slots1.epochNanoseconds ? 0 : countZonedDayWeekUnit(unit, timeZone, slots0, slots1, rounding);
}

function diffDateTimeCalendarUnit(unit, slots0, slots1, options) {
  const calendar = getCommonCalendar(slots0.calendar, slots1.calendar);
  return diffPlainRelativeUnit(unit, options, () => diffDateTimesExact(calendar, slots0, slots1, unit), createDateRelativeOps(calendar, slots0), computeEndEpochNanoFromMidnight(slots0, slots1));
}

function diffDateTimeWeeks(slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), countDateWeeks(slots0, computeEndEpochNanoFromMidnight(slots0, slots1), refineUnitDiffOptions(7, options));
}

function diffDateTimeDays(slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), countEpochNanoDays(isoDateTimeToEpochNano(slots0), isoDateTimeToEpochNano(slots1), timeFieldsToNano(slots0), refineUnitDiffOptions(6, options));
}

function computeEndEpochNanoFromMidnight(isoDateTime0, isoDateTime1) {
  return isoDateTimeToEpochNano(isoDateTime1) - BigInt(timeFieldsToNano(isoDateTime0));
}

function diffDateCalendarUnit(unit, slots0, slots1, options) {
  const calendar = getCommonCalendar(slots0.calendar, slots1.calendar);
  return diffPlainRelativeUnit(unit, options, () => diffCalendarDates(calendar, slots0, slots1, unit), createDateRelativeOps(calendar, slots0), isoDateToEpochNano(slots1));
}

function diffDateWeeks(slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), countDateWeeks(slots0, isoDateToEpochNano(slots1), refineUnitDiffOptions(7, options));
}

function diffDateDays(slots0, slots1, options) {
  return getCommonCalendar(slots0.calendar, slots1.calendar), countEpochNanoDays(isoDateToEpochNano(slots0), isoDateToEpochNano(slots1), 0, refineUnitDiffOptions(6, options));
}

function diffYearMonthUnit(unit, slots0, slots1, options) {
  const calendar = getCommonCalendar(slots0.calendar, slots1.calendar);
  return countYearMonthUnit(calendar, slots0, slots1, unit, refineUnitDiffOptions(unit, options));
}

function diffPlainRelativeUnit(unit, options, diffExact, relativeOps, endEpochNano) {
  return countRelativeUnit(unit, {
    he: diffExact,
    le: relativeOps,
    ie: endEpochNano
  }, refineUnitDiffOptions(unit, options));
}

function reversedMove(f) {
  return (slots, units, options) => f(slots, -units, options);
}

function moveDateByYears(calendar, isoDate, years, options) {
  const overflow = refineOverflowOptions(options);
  return years ? moveDateByCalendarUnits(calendar, isoDate, toStrictInteger(years), 0, overflow) : isoDate;
}

function moveDateByMonths(calendar, isoDate, months, options) {
  const overflow = refineOverflowOptions(options);
  return months ? moveDateByCalendarUnits(calendar, isoDate, 0, toStrictInteger(months), overflow) : isoDate;
}

function moveToDayOfYear(calendar, isoDate, dayOfYear, options) {
  const overflow = refineOverflowOptions(options);
  return moveToRefinedDayOfYear(calendar, isoDate, toIntegerWithTrunc(dayOfYear), overflow);
}

function moveToDayOfMonth(calendar, isoDate, day, options) {
  const overflow = refineOverflowOptions(options);
  return moveToRefinedDayOfMonth(calendar, isoDate, toPositiveIntegerWithTruncation(day), overflow);
}

function moveToDayOfWeek(_calendar, isoDate, dayOfWeek, options) {
  const overflow = refineOverflowOptions(options);
  return moveToRefinedDayOfWeek(isoDate, toIntegerWithTrunc(dayOfWeek), overflow);
}

function moveToWeekOfYear(calendar, isoDate, weekOfYear, options) {
  const overflow = refineOverflowOptions(options);
  return moveToRefinedWeekOfYear(calendar, isoDate, toIntegerWithTrunc(weekOfYear), overflow);
}

export { CalendarBranding, DurationBranding, InstantBranding, PlainDateBranding, PlainDateTimeBranding, PlainMonthDayBranding, PlainTimeBranding, PlainYearMonthBranding, ZonedDateTimeBranding, adaptRecordTimeUnitDiff, attachDebugString, dateDerivedGetters, dateFieldGetters$1 as dateFieldGetters, dateFieldGetters as dateFieldGetters$1, defineTemporalClass, diffDateDays, diffDateMonths, diffDateTimeDays, diffDateTimeEpochNanoTimeUnit, diffDateTimeMonths, diffDateTimeWeeks, diffDateTimeYears, diffDateTimes, diffDateWeeks, diffDateYears, diffDates, diffInstantEpochNanoTimeUnit, diffInstants, diffTimeNanoOfDayTimeUnit, diffTimes, diffYearMonthMonths, diffYearMonthYears, diffYearMonths, diffZonedDateTimes, diffZonedDays, diffZonedEpochNanoTimeUnit, diffZonedMonths, diffZonedWeeks, diffZonedYears, durationGetters, forbiddenValueOf, invalidRecordType, monthDayFieldGetters$1 as monthDayFieldGetters, monthDayFieldGetters as monthDayFieldGetters$1, moveDateByMonths, moveDateByYears, moveToDayOfMonth, moveToDayOfWeek, moveToDayOfYear, moveToWeekOfYear, reversedMove, timeGetters, withDateFields, withDateTimeFields, withMonthDayFields, withTimeFields, withYearMonthFields, withZonedDateTimeFields, yearMonthDerivedGetters, yearMonthFieldGetters$1 as yearMonthFieldGetters, yearMonthFieldGetters as yearMonthFieldGetters$1 };
