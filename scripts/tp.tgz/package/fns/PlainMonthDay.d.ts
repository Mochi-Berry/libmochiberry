import { Temporal } from 'temporal-spec';
import { MonthDayFields, LocalesArg, EraYearOrYear } from '../chunks/internal.js';
import { DateTimeFormatLike, PlainMonthDayRecord, MonthDayFromFields, CalendarRecord, OverflowOptions, PlainDateRecord } from '../chunks/funcApi.js';


type Format = DateTimeFormatLike<PlainMonthDayRecord>;
type FromFields = MonthDayFromFields<CalendarRecord>;
type WithFields = Partial<MonthDayFields>;
type ToStringOptions = Temporal.PlainDateToStringOptions;
declare const create: (isoMonth: number, isoDay: number, calendar?: CalendarRecord, referenceIsoYear?: number) => PlainMonthDayRecord;
declare const isRecord: (arg: unknown) => arg is PlainMonthDayRecord;
declare const fromFields: (fields: FromFields, options?: OverflowOptions) => PlainMonthDayRecord;
declare const fromString: (s: string, getCalendar: (calendarId: string) => CalendarRecord) => PlainMonthDayRecord;
declare const withFields: (record: PlainMonthDayRecord, mod: WithFields, options?: OverflowOptions) => PlainMonthDayRecord;
declare const equals: (record: PlainMonthDayRecord, otherRecord: PlainMonthDayRecord) => boolean;
declare const createFormat: (locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => Format;
declare const toLocaleString: (record: PlainMonthDayRecord, locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => string;
declare const toString: (record: PlainMonthDayRecord, options?: ToStringOptions) => string;
declare const toBasicString: (record: PlainMonthDayRecord) => string;
declare const toPlainDate: (record: PlainMonthDayRecord, fields: EraYearOrYear) => PlainDateRecord;
declare const toTemporal: (record: PlainMonthDayRecord) => Temporal.PlainMonthDay;

export { type Format, type FromFields, PlainMonthDayRecord as Record, type ToStringOptions, type WithFields, create, createFormat, equals, fromFields, fromString, isRecord, toBasicString, toLocaleString, toPlainDate, toString, toTemporal, withFields };
