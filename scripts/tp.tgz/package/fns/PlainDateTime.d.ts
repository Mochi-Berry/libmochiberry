import { Temporal } from 'temporal-spec';
import { DateTimeFields, LocalesArg } from '../chunks/internal.js';
import { DateTimeFormatLike, PlainDateTimeRecord, DateTimeFromFields, CalendarRecord, OverflowOptions, PlainTimeRecord, DurationRecord, DisambiguationOptions, ZonedDateTimeRecord, PlainDateRecord, RoundingMode, RoundingMathOptions } from '../chunks/funcApi.js';


type Format = DateTimeFormatLike<PlainDateTimeRecord>;
type FromFields = DateTimeFromFields<CalendarRecord>;
type WithFields = Partial<DateTimeFields>;
type DiffOptions = Temporal.RoundingOptionsWithLargestUnit<Temporal.DateUnit | Temporal.TimeUnit>;
type ToStringOptions = Temporal.PlainDateTimeToStringOptions;
declare const create: (isoYear: number, isoMonth: number, isoDay: number, hour?: number, minute?: number, second?: number, millisecond?: number, microsecond?: number, nanosecond?: number, calendar?: CalendarRecord) => PlainDateTimeRecord;
declare const isRecord: (arg: unknown) => arg is PlainDateTimeRecord;
declare const fromFields: (fields: FromFields, options?: OverflowOptions) => PlainDateTimeRecord;
declare const fromString: (s: string, getCalendar: (calendarId: string) => CalendarRecord) => PlainDateTimeRecord;
declare const withCalendar: (record: PlainDateTimeRecord, calendarRecord: CalendarRecord) => PlainDateTimeRecord;
declare const withFields: (record: PlainDateTimeRecord, mod: WithFields, options?: OverflowOptions) => PlainDateTimeRecord;
declare const withPlainTime: (record: PlainDateTimeRecord, plainTimeRecord?: PlainTimeRecord) => PlainDateTimeRecord;
declare const dayOfWeek: (record: PlainDateTimeRecord) => number;
declare const daysInWeek: (record: PlainDateTimeRecord) => number;
declare const weekOfYear: (record: PlainDateTimeRecord) => number | undefined;
declare const yearOfWeek: (record: PlainDateTimeRecord) => number | undefined;
declare const dayOfYear: (record: PlainDateTimeRecord) => number;
declare const daysInMonth: (record: PlainDateTimeRecord) => number;
declare const daysInYear: (record: PlainDateTimeRecord) => number;
declare const monthsInYear: (record: PlainDateTimeRecord) => number;
declare const inLeapYear: (record: PlainDateTimeRecord) => boolean;
declare const add: (record: PlainDateTimeRecord, duration: DurationRecord, options?: OverflowOptions) => PlainDateTimeRecord;
declare const subtract: (record: PlainDateTimeRecord, duration: DurationRecord, options?: OverflowOptions) => PlainDateTimeRecord;
declare const diff: (record: PlainDateTimeRecord, otherRecord: PlainDateTimeRecord, options?: DiffOptions) => DurationRecord;
declare const equals: (record: PlainDateTimeRecord, otherRecord: PlainDateTimeRecord) => boolean;
declare const compare: (record: PlainDateTimeRecord, otherRecord: PlainDateTimeRecord) => number;
declare const createFormat: (locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => Format;
declare const toLocaleString: (record: PlainDateTimeRecord, locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => string;
declare const toString: (record: PlainDateTimeRecord, options?: ToStringOptions) => string;
declare const toBasicString: (record: PlainDateTimeRecord) => string;
declare const toZonedDateTime: (record: PlainDateTimeRecord, timeZoneId: string, options?: DisambiguationOptions) => ZonedDateTimeRecord;
declare const toPlainDate: (record: PlainDateTimeRecord) => PlainDateRecord;
declare const toPlainTime: (record: PlainDateTimeRecord) => PlainTimeRecord;
declare const toTemporal: (record: PlainDateTimeRecord) => Temporal.PlainDateTime;
declare const withDayOfYear: (record: PlainDateTimeRecord, dayOfYear: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const withDayOfMonth: (record: PlainDateTimeRecord, dayOfMonth: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const withDayOfWeek: (record: PlainDateTimeRecord, dayOfWeek: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const withWeekOfYear: (record: PlainDateTimeRecord, weekOfYear: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const addYears: (record: PlainDateTimeRecord, years: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const addMonths: (record: PlainDateTimeRecord, months: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const addWeeks: (record: PlainDateTimeRecord, weeks: number) => PlainDateTimeRecord;
declare const addDays: (record: PlainDateTimeRecord, days: number) => PlainDateTimeRecord;
declare const addHours: (record: PlainDateTimeRecord, hours: number) => PlainDateTimeRecord;
declare const addMinutes: (record: PlainDateTimeRecord, minutes: number) => PlainDateTimeRecord;
declare const addSeconds: (record: PlainDateTimeRecord, seconds: number) => PlainDateTimeRecord;
declare const addMilliseconds: (record: PlainDateTimeRecord, milliseconds: number) => PlainDateTimeRecord;
declare const addMicroseconds: (record: PlainDateTimeRecord, microseconds: number) => PlainDateTimeRecord;
declare const addNanoseconds: (record: PlainDateTimeRecord, nanoseconds: number) => PlainDateTimeRecord;
declare const subtractYears: (record: PlainDateTimeRecord, years: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const subtractMonths: (record: PlainDateTimeRecord, months: number, options?: OverflowOptions) => PlainDateTimeRecord;
declare const subtractWeeks: (record: PlainDateTimeRecord, weeks: number) => PlainDateTimeRecord;
declare const subtractDays: (record: PlainDateTimeRecord, days: number) => PlainDateTimeRecord;
declare const subtractHours: (record: PlainDateTimeRecord, hours: number) => PlainDateTimeRecord;
declare const subtractMinutes: (record: PlainDateTimeRecord, minutes: number) => PlainDateTimeRecord;
declare const subtractSeconds: (record: PlainDateTimeRecord, seconds: number) => PlainDateTimeRecord;
declare const subtractMilliseconds: (record: PlainDateTimeRecord, milliseconds: number) => PlainDateTimeRecord;
declare const subtractMicroseconds: (record: PlainDateTimeRecord, microseconds: number) => PlainDateTimeRecord;
declare const subtractNanoseconds: (record: PlainDateTimeRecord, nanoseconds: number) => PlainDateTimeRecord;
declare const roundToYear: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToMonth: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToWeek: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToDay: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToHour: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToMinute: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToSecond: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToMillisecond: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const roundToMicrosecond: {
    (record: PlainDateTimeRecord): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, roundingMode: RoundingMode): PlainDateTimeRecord;
    (record: PlainDateTimeRecord, options: RoundingMathOptions): PlainDateTimeRecord;
};
declare const startOfYear: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfMonth: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfWeek: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfDay: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfHour: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfMinute: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfSecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfMillisecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const startOfMicrosecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfYear: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfMonth: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfWeek: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfDay: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfHour: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfMinute: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfSecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfMillisecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const endOfMicrosecond: (record: PlainDateTimeRecord) => PlainDateTimeRecord;
declare const diffYears: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffMonths: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffWeeks: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffDays: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffHours: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffMinutes: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffSeconds: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffMilliseconds: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffMicroseconds: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};
declare const diffNanoseconds: {
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateTimeRecord, record1: PlainDateTimeRecord, options: RoundingMathOptions): number;
};

export { type DiffOptions, type Format, type FromFields, PlainDateTimeRecord as Record, type ToStringOptions, type WithFields, add, addDays, addHours, addMicroseconds, addMilliseconds, addMinutes, addMonths, addNanoseconds, addSeconds, addWeeks, addYears, compare, create, createFormat, dayOfWeek, dayOfYear, daysInMonth, daysInWeek, daysInYear, diff, diffDays, diffHours, diffMicroseconds, diffMilliseconds, diffMinutes, diffMonths, diffNanoseconds, diffSeconds, diffWeeks, diffYears, endOfDay, endOfHour, endOfMicrosecond, endOfMillisecond, endOfMinute, endOfMonth, endOfSecond, endOfWeek, endOfYear, equals, fromFields, fromString, inLeapYear, isRecord, monthsInYear, roundToDay, roundToHour, roundToMicrosecond, roundToMillisecond, roundToMinute, roundToMonth, roundToSecond, roundToWeek, roundToYear, startOfDay, startOfHour, startOfMicrosecond, startOfMillisecond, startOfMinute, startOfMonth, startOfSecond, startOfWeek, startOfYear, subtract, subtractDays, subtractHours, subtractMicroseconds, subtractMilliseconds, subtractMinutes, subtractMonths, subtractNanoseconds, subtractSeconds, subtractWeeks, subtractYears, toBasicString, toLocaleString, toPlainDate, toPlainTime, toString, toTemporal, toZonedDateTime, weekOfYear, withCalendar, withDayOfMonth, withDayOfWeek, withDayOfYear, withFields, withPlainTime, withWeekOfYear, yearOfWeek };
