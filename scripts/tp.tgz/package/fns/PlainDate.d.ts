import { Temporal } from 'temporal-spec';
import { DateFields, LocalesArg } from '../chunks/internal.js';
import { DateTimeFormatLike, PlainDateRecord, DateFromFields, CalendarRecord, PlainDateToZonedDateTimeOptions, PlainTimeRecord, OverflowOptions, DurationRecord, ZonedDateTimeRecord, PlainDateTimeRecord, PlainYearMonthRecord, PlainMonthDayRecord, RoundingMode, RoundingMathOptions } from '../chunks/funcApi.js';


type Format = DateTimeFormatLike<PlainDateRecord>;
type FromFields = DateFromFields<CalendarRecord>;
type WithFields = Partial<DateFields>;
type DiffOptions = Temporal.RoundingOptionsWithLargestUnit<Temporal.DateUnit>;
type ToZonedDateTimeOptions = PlainDateToZonedDateTimeOptions<PlainTimeRecord>;
type ToStringOptions = Temporal.PlainDateToStringOptions;
declare const isRecord: (arg: unknown) => arg is PlainDateRecord;
declare const create: (isoYear: number, isoMonth: number, isoDay: number, calendar?: CalendarRecord) => PlainDateRecord;
declare const fromFields: (fields: FromFields, options?: OverflowOptions) => PlainDateRecord;
declare const fromString: (s: string, getCalendar: (calendarId: string) => CalendarRecord) => PlainDateRecord;
declare const dayOfWeek: (record: PlainDateRecord) => number;
declare const daysInWeek: (record: PlainDateRecord) => number;
declare const weekOfYear: (record: PlainDateRecord) => number | undefined;
declare const yearOfWeek: (record: PlainDateRecord) => number | undefined;
declare const dayOfYear: (record: PlainDateRecord) => number;
declare const daysInMonth: (record: PlainDateRecord) => number;
declare const daysInYear: (record: PlainDateRecord) => number;
declare const monthsInYear: (record: PlainDateRecord) => number;
declare const inLeapYear: (record: PlainDateRecord) => boolean;
declare const withFields: (record: PlainDateRecord, mod: WithFields, options?: OverflowOptions) => PlainDateRecord;
declare const withCalendar: (record: PlainDateRecord, calendarRecord: CalendarRecord) => PlainDateRecord;
declare const add: (record: PlainDateRecord, duration: DurationRecord, options?: OverflowOptions) => PlainDateRecord;
declare const subtract: (record: PlainDateRecord, duration: DurationRecord, options?: OverflowOptions) => PlainDateRecord;
declare const diff: (record: PlainDateRecord, otherRecord: PlainDateRecord, options?: DiffOptions) => DurationRecord;
declare const equals: (record: PlainDateRecord, otherRecord: PlainDateRecord) => boolean;
declare const compare: (record: PlainDateRecord, otherRecord: PlainDateRecord) => number;
declare const createFormat: (locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => Format;
declare const toLocaleString: (record: PlainDateRecord, locales?: LocalesArg, options?: Intl.DateTimeFormatOptions) => string;
declare const toString: (record: PlainDateRecord, options?: ToStringOptions) => string;
declare const toBasicString: (record: PlainDateRecord) => string;
declare const toZonedDateTime: {
    (record: PlainDateRecord, timeZoneId: string): ZonedDateTimeRecord;
    (record: PlainDateRecord, options: ToZonedDateTimeOptions): ZonedDateTimeRecord;
};
declare const toPlainDateTime: (record: PlainDateRecord, plainTimeRecord?: PlainTimeRecord) => PlainDateTimeRecord;
declare const toPlainYearMonth: (record: PlainDateRecord) => PlainYearMonthRecord;
declare const toPlainMonthDay: (record: PlainDateRecord) => PlainMonthDayRecord;
declare const toTemporal: (record: PlainDateRecord) => Temporal.PlainDate;
declare const withDayOfYear: (record: PlainDateRecord, dayOfYear: number, options?: OverflowOptions) => PlainDateRecord;
declare const withDayOfMonth: (record: PlainDateRecord, dayOfMonth: number, options?: OverflowOptions) => PlainDateRecord;
declare const withDayOfWeek: (record: PlainDateRecord, dayOfWeek: number, options?: OverflowOptions) => PlainDateRecord;
declare const withWeekOfYear: (record: PlainDateRecord, weekOfYear: number, options?: OverflowOptions) => PlainDateRecord;
declare const addYears: (record: PlainDateRecord, years: number, options?: OverflowOptions) => PlainDateRecord;
declare const addMonths: (record: PlainDateRecord, months: number, options?: OverflowOptions) => PlainDateRecord;
declare const addWeeks: (record: PlainDateRecord, weeks: number) => PlainDateRecord;
declare const addDays: (record: PlainDateRecord, days: number) => PlainDateRecord;
declare const subtractYears: (record: PlainDateRecord, units: number, options?: OverflowOptions) => PlainDateRecord;
declare const subtractMonths: (record: PlainDateRecord, units: number, options?: OverflowOptions) => PlainDateRecord;
declare const subtractWeeks: (record: PlainDateRecord, units: number, options?: OverflowOptions) => PlainDateRecord;
declare const subtractDays: (record: PlainDateRecord, units: number, options?: OverflowOptions) => PlainDateRecord;
declare const roundToYear: {
    (record: PlainDateRecord): PlainDateRecord;
    (record: PlainDateRecord, roundingMode: RoundingMode): PlainDateRecord;
    (record: PlainDateRecord, options: RoundingMathOptions): PlainDateRecord;
};
declare const roundToMonth: {
    (record: PlainDateRecord): PlainDateRecord;
    (record: PlainDateRecord, roundingMode: RoundingMode): PlainDateRecord;
    (record: PlainDateRecord, options: RoundingMathOptions): PlainDateRecord;
};
declare const roundToWeek: {
    (record: PlainDateRecord): PlainDateRecord;
    (record: PlainDateRecord, roundingMode: RoundingMode): PlainDateRecord;
    (record: PlainDateRecord, options: RoundingMathOptions): PlainDateRecord;
};
declare const startOfYear: (record: PlainDateRecord) => PlainDateRecord;
declare const startOfMonth: (record: PlainDateRecord) => PlainDateRecord;
declare const startOfWeek: (record: PlainDateRecord) => PlainDateRecord;
declare const endOfYear: (record: PlainDateRecord) => PlainDateRecord;
declare const endOfMonth: (record: PlainDateRecord) => PlainDateRecord;
declare const endOfWeek: (record: PlainDateRecord) => PlainDateRecord;
declare const diffYears: {
    (record0: PlainDateRecord, record1: PlainDateRecord): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, options: RoundingMathOptions): number;
};
declare const diffMonths: {
    (record0: PlainDateRecord, record1: PlainDateRecord): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, options: RoundingMathOptions): number;
};
declare const diffWeeks: {
    (record0: PlainDateRecord, record1: PlainDateRecord): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, options: RoundingMathOptions): number;
};
declare const diffDays: {
    (record0: PlainDateRecord, record1: PlainDateRecord): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, roundingMode: RoundingMode): number;
    (record0: PlainDateRecord, record1: PlainDateRecord, options: RoundingMathOptions): number;
};

export { type DiffOptions, type Format, type FromFields, PlainDateRecord as Record, type ToStringOptions, type ToZonedDateTimeOptions, type WithFields, add, addDays, addMonths, addWeeks, addYears, compare, create, createFormat, dayOfWeek, dayOfYear, daysInMonth, daysInWeek, daysInYear, diff, diffDays, diffMonths, diffWeeks, diffYears, endOfMonth, endOfWeek, endOfYear, equals, fromFields, fromString, inLeapYear, isRecord, monthsInYear, roundToMonth, roundToWeek, roundToYear, startOfMonth, startOfWeek, startOfYear, subtract, subtractDays, subtractMonths, subtractWeeks, subtractYears, toBasicString, toLocaleString, toPlainDateTime, toPlainMonthDay, toPlainYearMonth, toString, toTemporal, toZonedDateTime, weekOfYear, withCalendar, withDayOfMonth, withDayOfWeek, withDayOfYear, withFields, withWeekOfYear, yearOfWeek };
